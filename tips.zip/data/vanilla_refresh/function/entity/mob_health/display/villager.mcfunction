# Переписано нами. Оригинал печатал здоровье прямо в строку действия и
# затирал HUD артефактов. Теперь надпись уходит в smithed.actionbar без
# приоритета: библиотека покажет её, только если строка свободна.
# Если Vanilla Refresh обновится — сверить с оригиналом и перенести правки.


execute if data entity @s VillagerData{level:1} run data modify storage smithed.actionbar:input message.json set value [{"translate":"","color": "yellow"},{"translate":"◆ ","color":"#b5b5b5"},{"selector":"@n[distance=0.001..5,tag=refresh_temp792_mob]","color": "#b5b5b5"},{"translate": " - ","color": "gray"},{"translate": "❤ ","color":"yellow"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_health"}},{"translate": "/","color": "#bababa"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_maxhealth"},"color":"#bababa"}]

execute if data entity @s VillagerData{level:2} run data modify storage smithed.actionbar:input message.json set value [{"translate":"","color": "yellow"},{"translate":"◆ ","color":"#e37849"},{"selector":"@n[distance=0.001..5,tag=refresh_temp792_mob]","color": "#e37849"},{"translate": " - ","color": "gray"},{"translate": "❤ ","color":"yellow"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_health"}},{"translate": "/","color": "#bababa"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_maxhealth"},"color":"#bababa"}]

execute if data entity @s VillagerData{level:3} run data modify storage smithed.actionbar:input message.json set value [{"translate":"","color": "yellow"},{"translate":"◆ ","color":"#e3ca0b"},{"selector":"@n[distance=0.001..5,tag=refresh_temp792_mob]","color": "#e3ca0b"},{"translate": " - ","color": "gray"},{"translate": "❤ ","color":"yellow"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_health"}},{"translate": "/","color": "#bababa"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_maxhealth"},"color":"#bababa"}]

execute if data entity @s VillagerData{level:4} run data modify storage smithed.actionbar:input message.json set value [{"translate":"","color": "yellow"},{"translate":"◆ ","color":"#3dff8b"},{"selector":"@n[distance=0.001..5,tag=refresh_temp792_mob]","color": "#3dff8b"},{"translate": " - ","color": "gray"},{"translate": "❤ ","color":"yellow"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_health"}},{"translate": "/","color": "#bababa"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_maxhealth"},"color":"#bababa"}]

execute if data entity @s VillagerData{level:5} run data modify storage smithed.actionbar:input message.json set value [{"translate":"","color": "yellow"},{"translate":"◆ ","color":"#54fcff"},{"selector":"@n[distance=0.001..5,tag=refresh_temp792_mob]","color": "#54fcff"},{"translate": " - ","color": "gray"},{"translate": "❤ ","color":"yellow"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_health"}},{"translate": "/","color": "#bababa"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_maxhealth"},"color":"#bababa"}]



#unemployed

execute if data entity @s VillagerData{profession:"minecraft:none"} run data modify storage smithed.actionbar:input message.json set value [{"translate":"","color": "yellow"},{"selector":"@n[distance=0.001..5,tag=refresh_temp792_mob]","color": "green"},{"translate": " - ","color": "gray"},{"translate": "❤ ","color":"yellow"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_health"}},{"translate": "/","color": "#bababa"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_maxhealth"},"color":"#bababa"}]

execute if data entity @s VillagerData{profession:"minecraft:nitwit"} run data modify storage smithed.actionbar:input message.json set value [{"translate":"","color": "yellow"},{"selector":"@n[distance=0.001..5,tag=refresh_temp792_mob]","color": "green"},{"translate": " - ","color": "gray"},{"translate": "❤ ","color":"yellow"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_health"}},{"translate": "/","color": "#bababa"},{"score":{"name": "@n[distance=0.001..5,tag=refresh_temp792_mob]","objective": "refresh_maxhealth"},"color":"#bababa"}]
