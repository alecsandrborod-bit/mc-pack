# Выдаёт чистый предмет ввода, а дальше пять раз подряд вызывает
# настоящую функцию мода svm_ep:menu/bind/to_item — ту же самую, что стоит
# за кнопкой «Bind» в меню. Числа для неё считаем сами (id×10 + номер
# клавиши, для приседания ещё умножаем на -1), а дальше уже мод сам пишет
# нужные NBT и подпись на предмете — мы ничего не подделываем руками,
# только жмём ту же кнопку за игрока пять раз, для каждой привязанной
# клавиши. Слоты: 1 — ПКМ, 2 — F/вторая рука, 3 — Q/выброс, 4 — прыжок,
# 5 — бег.

summon minecraft:item_display ~ ~ ~ {Tags:["svm_ep.temporary_storage"]}
loot replace entity @n[tag=svm_ep.temporary_storage] contents loot svm_ep:items/ability_input/default
item replace entity @s weapon.mainhand from entity @n[tag=svm_ep.temporary_storage] contents
kill @n[tag=svm_ep.temporary_storage]

execute if score @s svm_ep.selected_ability.input_item.using_item matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.using_item
execute if score @s svm_ep.selected_ability.input_item.using_item matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.using_item matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 1
execute if score @s svm_ep.selected_ability.input_item.using_item matches 1.. run function svm_ep:menu/bind/to_item

execute if score @s svm_ep.selected_ability.input_item.sneak.using_item matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.sneak.using_item
execute if score @s svm_ep.selected_ability.input_item.sneak.using_item matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.using_item matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 1
execute if score @s svm_ep.selected_ability.input_item.sneak.using_item matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %-1 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.using_item matches 1.. run function svm_ep:menu/bind/to_item

execute if score @s svm_ep.selected_ability.input_item.offhand matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.offhand
execute if score @s svm_ep.selected_ability.input_item.offhand matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.offhand matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 2
execute if score @s svm_ep.selected_ability.input_item.offhand matches 1.. run function svm_ep:menu/bind/to_item

execute if score @s svm_ep.selected_ability.input_item.sneak.offhand matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.sneak.offhand
execute if score @s svm_ep.selected_ability.input_item.sneak.offhand matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.offhand matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 2
execute if score @s svm_ep.selected_ability.input_item.sneak.offhand matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %-1 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.offhand matches 1.. run function svm_ep:menu/bind/to_item

execute if score @s svm_ep.selected_ability.input_item.dropped matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.dropped
execute if score @s svm_ep.selected_ability.input_item.dropped matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.dropped matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 3
execute if score @s svm_ep.selected_ability.input_item.dropped matches 1.. run function svm_ep:menu/bind/to_item

execute if score @s svm_ep.selected_ability.input_item.sneak.dropped matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.sneak.dropped
execute if score @s svm_ep.selected_ability.input_item.sneak.dropped matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.dropped matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 3
execute if score @s svm_ep.selected_ability.input_item.sneak.dropped matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %-1 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.dropped matches 1.. run function svm_ep:menu/bind/to_item

execute if score @s svm_ep.selected_ability.input_item.jump matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.jump
execute if score @s svm_ep.selected_ability.input_item.jump matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.jump matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 4
execute if score @s svm_ep.selected_ability.input_item.jump matches 1.. run function svm_ep:menu/bind/to_item

execute if score @s svm_ep.selected_ability.input_item.sneak.jump matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.sneak.jump
execute if score @s svm_ep.selected_ability.input_item.sneak.jump matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.jump matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 4
execute if score @s svm_ep.selected_ability.input_item.sneak.jump matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %-1 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.jump matches 1.. run function svm_ep:menu/bind/to_item

execute if score @s svm_ep.selected_ability.input_item.sprint matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.sprint
execute if score @s svm_ep.selected_ability.input_item.sprint matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sprint matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 5
execute if score @s svm_ep.selected_ability.input_item.sprint matches 1.. run function svm_ep:menu/bind/to_item

execute if score @s svm_ep.selected_ability.input_item.sneak.sprint matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item = @s svm_ep.selected_ability.input_item.sneak.sprint
execute if score @s svm_ep.selected_ability.input_item.sneak.sprint matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %10 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.sprint matches 1.. run scoreboard players add @s svm_ep.z.bind_ability.to_item 5
execute if score @s svm_ep.selected_ability.input_item.sneak.sprint matches 1.. run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %-1 svm_ep.numbers
execute if score @s svm_ep.selected_ability.input_item.sneak.sprint matches 1.. run function svm_ep:menu/bind/to_item

tellraw @s [{"text":"[SVM Powers] ","color":"light_purple"},{"text":"Предмет ввода потерян — выдан новый со старыми привязками.","color":"gray"}]
