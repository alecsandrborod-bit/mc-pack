# Не трогаем игрока, если рука занята: мод сам даёт предмет ввода только
# в пустую основную руку («Requires empty mainhand!»), и мы не должны
# сносить то, что игрок держит по своим делам. Просто подождём следующей
# проверки — рука рано или поздно освободится.
execute if items entity @s weapon.mainhand * run return 0

# Уже есть предмет ввода — восстанавливать нечего.
execute if items entity @s weapon.* *[minecraft:custom_data~{svm_ep.item:{id:"input_item"}}] run return 0
execute if items entity @s container.* *[minecraft:custom_data~{svm_ep.item:{id:"input_item"}}] run return 0

# Предмета нет. Восстанавливаем, только если раньше что-то было привязано —
# иначе выдали бы этот предмет и тем, кто им никогда не пользовался.
execute if score @s svm_ep.selected_ability.input_item.using_item matches 1.. run return run function tips:svm_input_restore/give_and_rebind
execute if score @s svm_ep.selected_ability.input_item.sneak.using_item matches 1.. run return run function tips:svm_input_restore/give_and_rebind
execute if score @s svm_ep.selected_ability.input_item.offhand matches 1.. run return run function tips:svm_input_restore/give_and_rebind
execute if score @s svm_ep.selected_ability.input_item.sneak.offhand matches 1.. run return run function tips:svm_input_restore/give_and_rebind
execute if score @s svm_ep.selected_ability.input_item.dropped matches 1.. run return run function tips:svm_input_restore/give_and_rebind
execute if score @s svm_ep.selected_ability.input_item.sneak.dropped matches 1.. run return run function tips:svm_input_restore/give_and_rebind
execute if score @s svm_ep.selected_ability.input_item.jump matches 1.. run return run function tips:svm_input_restore/give_and_rebind
execute if score @s svm_ep.selected_ability.input_item.sneak.jump matches 1.. run return run function tips:svm_input_restore/give_and_rebind
execute if score @s svm_ep.selected_ability.input_item.sprint matches 1.. run return run function tips:svm_input_restore/give_and_rebind
execute if score @s svm_ep.selected_ability.input_item.sneak.sprint matches 1.. run return run function tips:svm_input_restore/give_and_rebind
