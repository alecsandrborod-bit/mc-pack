# Ancient Artifacts, браслет некроманта: призванный зомби появляется
# на 2 блока под землёй и 2 секунды (40 тиков) поднимается наверх, но сам
# мод не даёт ему на это время неуязвимость — и зомби почти всегда
# задыхается в земле, не успев вылезти. У точно такой же анимации выхода
# из-под земли в том же моде (sculk_heart/waves/summon_anim.mcfunction)
# такая защита есть (Invulnerable:1b, пока не поднялся) — здесь её просто
# забыли. Достраиваем её снаружи, не трогая сам мод.
#
# Счёт lifetime мод ведёт НЕ на самом зомби, а на волке-невидимке, что
# сидит на нём верхом и толкает его наверх — вся анимация в
# necromanced.mcfunction выполняется как волк (вызов: `as @e[type=wolf,
# tag=necromanced, tag=controller] at @s run function ...necromanced`).
# Поэтому ищем волка по его счёту, а неуязвимость через `on vehicle`
# ставим на того, кого он везёт, — то есть на самого зомби.
#
# Первую строку — через unless ... matches 41.., а не через scores=..40:
# счёт lifetime у волка появляется только на первом же вызове necromanced
# (там же, где встаёт tag necromanced), а фильтр scores у сущностей не
# совпадает с ещё не существующим счётом. unless matches 41.. верно
# засчитывает и «счёта ещё нет», и «есть, но меньше 41» — так неуязвимость
# стоит с первого тика, а не со второго.
execute as @e[type=wolf, tag=necromanced, tag=controller] unless score @s lifetime matches 41.. on vehicle run data merge entity @s {Invulnerable:1b}
execute as @e[type=wolf, tag=necromanced, tag=controller, scores={lifetime=41}] on vehicle run data merge entity @s {Invulnerable:0b}
