# Заводим счётчик подсказок и запускаем цикл.
# Выполняется при загрузке мира и при каждом /reload.

scoreboard objectives add tips dummy
scoreboard players add #i tips 0

# 180s, а не 3m: игра понимает только t (тики), s и d — минут в ней нет.
# replace гасит старое задание — без этого после /reload
# подсказки начали бы сыпаться по два раза
schedule function tips:announce 180s replace
