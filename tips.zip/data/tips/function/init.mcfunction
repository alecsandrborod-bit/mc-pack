# Заводим счётчик подсказок и запускаем цикл.
# Выполняется при загрузке мира и при каждом /reload.

scoreboard objectives add tips dummy
scoreboard players add #i tips 0

# Прячет строки вроде «Задействован триггер [Fabled Roots: Infos]»: меню
# мода открывается через /trigger, и игра всякий раз отчитывается об этом
# в чат. Правило гасит отчёты команд, но не трогает tellraw — подсказки
# и сообщения модов доходят как прежде.
# Ставим здесь, а не через консоль: так оно переживёт любой перезапуск
# и лежит в репозитории вместе с остальным.
# В 26.x геймрулы переименованы в змеиный регистр: не sendCommandFeedback,
# а send_command_feedback. Старое имя игра не принимает, и вся функция
# из-за этого не грузится целиком — с ней и подсказки.
gamerule send_command_feedback false

# Мобы начинают появляться в броне со случайными узорами — это Vanilla
# Refresh, он уже стоял, просто был выключен. Ставим саму настройку, а не
# зовём функцию мода: та заодно открывает меню и играет звук игроку,
# а при загрузке мира игрока нет.
# ЧТОБЫ ВЫКЛЮЧИТЬ: убрать эту строку, иначе она вернёт всё обратно
# при следующем запуске, что бы вы ни выбрали в меню мода.
data modify storage vanilla_refresh_config:config config.armortrimmed_mobs set value 1

# Показ здоровья мобов оставляем включённым: две его функции мы переписали
# (`data/vanilla_refresh/.../mob_health/display/`), и теперь надпись идёт
# через smithed.actionbar без приоритета. Пока HUD артефактов занимает
# строку — здоровье молчит, освободилась — показывается.
data modify storage vanilla_refresh_config:config config.mob_health set value 1

# 180s, а не 3m: игра понимает только t (тики), s и d — минут в ней нет.
# replace гасит старое задание — без этого после /reload
# подсказки начали бы сыпаться по два раза
schedule function tips:announce 180s replace

# Чинит потерю привязанного «предмета ввода» SVM Powers — см. комментарий
# в svm_input_restore/check.mcfunction.
schedule function tips:svm_input_restore/check 100t replace
