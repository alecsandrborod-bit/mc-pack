# minecraft:pale_oak_shelf на -2680 67 2275 — 2 слотов
item replace block -2680 67 2275 container.0 with minecraft:music_disc_otherside["minecraft:custom_model_data":{strings:["harmonic_horizons:item/music_disc_castanuelas"]},"minecraft:jukebox_playable":"minecraft:castanuelas","minecraft:rarity":"uncommon"] 1
item replace block -2680 67 2275 container.1 with minecraft:music_disc_otherside 1
