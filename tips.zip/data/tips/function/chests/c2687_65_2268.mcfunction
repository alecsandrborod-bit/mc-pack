# minecraft:chest на -2687 65 2268 — 17 слотов
item replace block -2687 65 2268 container.0 with minecraft:leather 64
item replace block -2687 65 2268 container.1 with minecraft:leather 24
item replace block -2687 65 2268 container.2 with minecraft:glow_ink_sac 37
item replace block -2687 65 2268 container.3 with minecraft:warped_fungus 26
item replace block -2687 65 2268 container.4 with minecraft:pufferfish 25
item replace block -2687 65 2268 container.5 with minecraft:ink_sac 22
item replace block -2687 65 2268 container.6 with minecraft:crimson_fungus 20
item replace block -2687 65 2268 container.7 with minecraft:red_mushroom 18
item replace block -2687 65 2268 container.8 with minecraft:tropical_fish_bucket 10
item replace block -2687 65 2268 container.9 with minecraft:fermented_spider_eye 8
item replace block -2687 65 2268 container.10 with minecraft:cod_bucket 6
item replace block -2687 65 2268 container.11 with minecraft:tadpole_bucket 4
item replace block -2687 65 2268 container.12 with minecraft:rabbit_foot 3
item replace block -2687 65 2268 container.13 with minecraft:rabbit_hide 3
item replace block -2687 65 2268 container.14 with minecraft:pufferfish_bucket 2
item replace block -2687 65 2268 container.15 with minecraft:turtle_scute 1
item replace block -2687 65 2268 container.16 with minecraft:salmon_bucket 1
