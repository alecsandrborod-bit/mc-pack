# minecraft:chest на -2688 68 2268 — 4 слотов
item replace block -2688 68 2268 container.0 with minecraft:coal 64
item replace block -2688 68 2268 container.1 with minecraft:coal 5
item replace block -2688 68 2268 container.2 with minecraft:flint 63
item replace block -2688 68 2268 container.3 with minecraft:charcoal 7
