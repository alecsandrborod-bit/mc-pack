# minecraft:chest на -2688 68 2268 — 7 слотов
item replace block -2688 68 2268 container.0 with minecraft:coal 64
item replace block -2688 68 2268 container.1 with minecraft:coal 64
item replace block -2688 68 2268 container.2 with minecraft:coal 61
item replace block -2688 68 2268 container.3 with minecraft:flint 63
item replace block -2688 68 2268 container.4 with minecraft:coal_ore 47
item replace block -2688 68 2268 container.5 with minecraft:charcoal 7
item replace block -2688 68 2268 container.6 with minecraft:coal_block 3
