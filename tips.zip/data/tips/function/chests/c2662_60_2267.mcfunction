# minecraft:furnace на -2662 60 2267 — 1 слотов
item replace block -2662 60 2267 container.0 with minecraft:coal 13
