# minecraft:chest на -2683 67 2278 — 8 слотов
item replace block -2683 67 2278 container.0 with minecraft:flint_and_steel[minecraft:custom_data={weapon:"soul_steel"},minecraft:custom_name={color:"aqua",italic:0b,text:"Душевное огниво"},minecraft:lore=[{color:"green",italic:0b,text:"Способность:"},{color:"gray",italic:0b,text:"ПКМ по скалковым блокам, чтобы"},{color:"gray",italic:0b,text:"мгновенно расчистить от них большую площадь."}]] 10
item replace block -2683 67 2278 container.1 with minecraft:flint_and_steel 9
item replace block -2683 67 2278 container.2 with minecraft:shears 9
item replace block -2683 67 2278 container.3 with minecraft:shears[minecraft:consumable={animation:"none",consume_seconds:99999.0f,has_consume_particles:0b},minecraft:custom_data={usable:1b}] 3
item replace block -2683 67 2278 container.4 with minecraft:shears[minecraft:consumable={animation:"none",consume_seconds:99999.0f,has_consume_particles:0b},minecraft:custom_data={usable:1b},minecraft:damage=230] 1
item replace block -2683 67 2278 container.5 with minecraft:fishing_rod[minecraft:enchantments={"minecraft:lure":2}] 1
item replace block -2683 67 2278 container.6 with minecraft:shears[minecraft:consumable={animation:"none",consume_seconds:99999.0f,has_consume_particles:0b},minecraft:custom_data={usable:1b},minecraft:damage=156] 1
item replace block -2683 67 2278 container.7 with minecraft:shears[minecraft:consumable={animation:"none",consume_seconds:99999.0f,has_consume_particles:0b},minecraft:custom_data={usable:1b},minecraft:damage=89] 1
