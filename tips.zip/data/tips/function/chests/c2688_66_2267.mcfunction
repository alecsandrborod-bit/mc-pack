# minecraft:chest на -2688 66 2267 — 7 слотов
item replace block -2688 66 2267 container.0 with minecraft:ender_pearl 64
item replace block -2688 66 2267 container.1 with minecraft:ender_pearl 64
item replace block -2688 66 2267 container.2 with minecraft:ender_pearl 64
item replace block -2688 66 2267 container.3 with minecraft:ender_pearl 45
item replace block -2688 66 2267 container.4 with minecraft:fire_charge 64
item replace block -2688 66 2267 container.5 with minecraft:fire_charge 20
item replace block -2688 66 2267 container.6 with minecraft:ender_eye 5
