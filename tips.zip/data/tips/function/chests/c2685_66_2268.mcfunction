# minecraft:chest на -2685 66 2268 — 6 слотов
item replace block -2685 66 2268 container.0 with minecraft:iron_horse_armor 6
item replace block -2685 66 2268 container.1 with minecraft:saddle 2
item replace block -2685 66 2268 container.2 with minecraft:copper_horse_armor 2
item replace block -2685 66 2268 container.3 with minecraft:diamond_horse_armor 1
item replace block -2685 66 2268 container.4 with minecraft:golden_horse_armor 1
item replace block -2685 66 2268 container.5 with fabled_roots:golden_horse_armor_of_roots["minecraft:custom_data":{fabled_roots:{item:"golden_horse_armor_of_roots",root_color:1b}},"minecraft:equippable":{allowed_entities:"#minecraft:can_wear_horse_armor",asset_id:"fabled_roots:golden_horse_armor_of_roots",can_be_sheared:1b,damage_on_hurt:0b,equip_on_interact:1b,equip_sound:"minecraft:item.armor.equip_gold",slot:"body"},"minecraft:item_model":"fabled_roots:golden_horse_armor_of_roots","minecraft:item_name":{translate:"item.fabled_roots.golden_horse_armor_of_roots"},"minecraft:lore":[{color:"gray",italic:0b,translate:"item.fabled_roots.golden_horse_armor_of_roots.description"}],"minecraft:rarity":"uncommon","minecraft:tooltip_style":"fabled_roots:generic"] 1
