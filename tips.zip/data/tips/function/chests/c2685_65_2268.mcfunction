# minecraft:chest на -2685 65 2268 — 22 слотов
item replace block -2685 65 2268 container.0 with minecraft:white_banner[minecraft:banner_patterns=[{color:"black",pattern:"minecraft:rhombus"},{color:"orange",pattern:"minecraft:curly_border"},{color:"orange",pattern:"minecraft:circle"},{color:"orange",pattern:"minecraft:creeper"},{color:"orange",pattern:"minecraft:triangle_top"}]] 2
item replace block -2685 65 2268 container.1 with minecraft:orange_banner[minecraft:banner_patterns=[{color:"yellow",pattern:"minecraft:bricks"},{color:"cyan",pattern:"minecraft:half_horizontal"},{color:"lime",pattern:"minecraft:flower"},{color:"cyan",pattern:"minecraft:border"},{color:"lime",pattern:"minecraft:circle"},{color:"cyan",pattern:"minecraft:curly_border"}]] 2
item replace block -2685 65 2268 container.2 with minecraft:light_gray_wool 2
item replace block -2685 65 2268 container.3 with minecraft:glow_item_frame 2
item replace block -2685 65 2268 container.4 with minecraft:compass 1
item replace block -2685 65 2268 container.5 with minecraft:enchanted_book[minecraft:stored_enchantments={"enchantplus:mounted/cavalier_egis":2}] 1
item replace block -2685 65 2268 container.6 with minecraft:diamond_spear[minecraft:attribute_modifiers=[{amount:3.0d,id:"fabled_roots:vanilla_attack",operation:"add_value",slot:"mainhand",type:"minecraft:attack_damage"},{amount:-3.05d,id:"fabled_roots:vanilla_speed",operation:"add_value",slot:"mainhand",type:"minecraft:attack_speed"}],minecraft:custom_data={fabled_roots:{type:"spear"}},minecraft:enchantments={"minecraft:smite":3,"nova_structures:spiteful":2},minecraft:tooltip_style="fabled_roots:aetherian"] 1
item replace block -2685 65 2268 container.7 with minecraft:diamond_ore 1
item replace block -2685 65 2268 container.8 with minecraft:trial_key[minecraft:custom_model_data={floats:[724.0f]},minecraft:item_name={fallback:"Cave Chamber Key",translate:"item.dnt.cave_chamber_key"}] 1
item replace block -2685 65 2268 container.9 with minecraft:beetroot_soup 1
item replace block -2685 65 2268 container.10 with minecraft:white_banner[minecraft:banner_patterns=[{color:"green",pattern:"minecraft:stripe_top"},{color:"green",pattern:"minecraft:stripe_top"},{color:"orange",pattern:"minecraft:stripe_bottom"},{color:"orange",pattern:"minecraft:stripe_bottom"}]] 1
item replace block -2685 65 2268 container.11 with minecraft:writable_book 1
item replace block -2685 65 2268 container.12 with minecraft:flower_pot 1
item replace block -2685 65 2268 container.13 with minecraft:oak_sapling 1
item replace block -2685 65 2268 container.14 with minecraft:enchanted_book[minecraft:stored_enchantments={"enchantplus:elytra/kinetic_protection":1}] 1
item replace block -2685 65 2268 container.15 with minecraft:feather 1
item replace block -2685 65 2268 container.16 with minecraft:bow 1
item replace block -2685 65 2268 container.17 with minecraft:flint 1
item replace block -2685 65 2268 container.18 with minecraft:loom 1
item replace block -2685 65 2268 container.19 with minecraft:rabbit_foot 1
item replace block -2685 65 2268 container.20 with minecraft:golden_apple 1
item replace block -2685 65 2268 container.21 with minecraft:glass_bottle 1
