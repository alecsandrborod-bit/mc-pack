# minecraft:pale_oak_shelf на -2680 67 2274 — 2 слотов
item replace block -2680 67 2274 container.0 with minecraft:music_disc_11[minecraft:jukebox_playable="minecraft:teen_spirit",minecraft:rarity="rare"] 1
item replace block -2680 67 2274 container.1 with minecraft:music_disc_ward[minecraft:jukebox_playable="minecraft:bohemian_rhapsody",minecraft:rarity="rare"] 1
