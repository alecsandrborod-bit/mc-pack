# minecraft:furnace на -2680 66 2272 — 3 слотов
item replace block -2680 66 2272 container.0 with minecraft:raw_iron 64
item replace block -2680 66 2272 container.1 with minecraft:raw_iron 52
item replace block -2680 66 2272 container.2 with minecraft:coal 64
