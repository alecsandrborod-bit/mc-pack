# minecraft:chest на -2683 65 2268 — 3 слотов
item replace block -2683 65 2268 container.0 with minecraft:white_bed 2
item replace block -2683 65 2268 container.1 with minecraft:cyan_bed 1
item replace block -2683 65 2268 container.2 with minecraft:black_bed 1
