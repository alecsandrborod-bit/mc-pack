# minecraft:furnace на -2662 60 2266 — 3 слотов
item replace block -2662 60 2266 container.0 with minecraft:raw_iron 28
item replace block -2662 60 2266 container.1 with minecraft:raw_gold 22
item replace block -2662 60 2266 container.2 with minecraft:coal 19
