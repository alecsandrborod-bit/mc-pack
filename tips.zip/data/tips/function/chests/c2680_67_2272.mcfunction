# minecraft:furnace на -2680 67 2272 — 3 слотов
item replace block -2680 67 2272 container.0 with minecraft:beef 64
item replace block -2680 67 2272 container.1 with minecraft:coal 55
item replace block -2680 67 2272 container.2 with minecraft:potato 55
