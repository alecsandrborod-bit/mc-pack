# minecraft:chest на -2689 67 2268 — 10 слотов
item replace block -2689 67 2268 container.0 with minecraft:copper_ingot 64
item replace block -2689 67 2268 container.1 with minecraft:copper_ingot 64
item replace block -2689 67 2268 container.2 with minecraft:copper_ingot 64
item replace block -2689 67 2268 container.3 with minecraft:copper_ingot 64
item replace block -2689 67 2268 container.4 with minecraft:copper_ingot 35
item replace block -2689 67 2268 container.5 with minecraft:raw_copper 64
item replace block -2689 67 2268 container.6 with minecraft:raw_copper 64
item replace block -2689 67 2268 container.7 with minecraft:raw_copper 64
item replace block -2689 67 2268 container.8 with minecraft:raw_copper 34
item replace block -2689 67 2268 container.9 with minecraft:copper_nugget 38
