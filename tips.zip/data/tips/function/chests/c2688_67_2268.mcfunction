# minecraft:chest на -2688 67 2268 — 6 слотов
item replace block -2688 67 2268 container.0 with minecraft:phantom_membrane 26
item replace block -2688 67 2268 container.1 with minecraft:clay 64
item replace block -2688 67 2268 container.2 with minecraft:clay 15
item replace block -2688 67 2268 container.3 with minecraft:clay_ball 37
item replace block -2688 67 2268 container.4 with minecraft:glowstone_dust 10
item replace block -2688 67 2268 container.5 with minecraft:sulfur_spike 1
