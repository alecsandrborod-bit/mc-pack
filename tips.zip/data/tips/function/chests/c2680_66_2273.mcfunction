# minecraft:furnace на -2680 66 2273 — 3 слотов
item replace block -2680 66 2273 container.0 with minecraft:raw_iron 64
item replace block -2680 66 2273 container.1 with minecraft:raw_iron 64
item replace block -2680 66 2273 container.2 with minecraft:raw_iron 64
