# minecraft:furnace на -2662 61 2266 — 1 слотов
item replace block -2662 61 2266 container.0 with minecraft:deepslate_diamond_ore 5
