# minecraft:furnace на -2662 61 2266 — 2 слотов
item replace block -2662 61 2266 container.0 with minecraft:coal 64
item replace block -2662 61 2266 container.1 with minecraft:deepslate_diamond_ore 5
