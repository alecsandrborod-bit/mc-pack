# minecraft:furnace на -2662 59 2266 — 1 слотов
item replace block -2662 59 2266 container.0 with minecraft:coal 64
