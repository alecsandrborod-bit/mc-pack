# minecraft:chest на -2680 84 2274 — 1 слотов
item replace block -2680 84 2274 container.0 with minecraft:cobblestone_stairs 1
