# minecraft:chest на -2683 65 2278 — 11 слотов
item replace block -2683 65 2278 container.0 with minecraft:crossbow 4
item replace block -2683 65 2278 container.1 with minecraft:crossbow["minecraft:enchantments":{"minecraft:piercing":4,"minecraft:quick_charge":2}] 2
item replace block -2683 65 2278 container.2 with minecraft:crossbow["minecraft:damage":204] 1
item replace block -2683 65 2278 container.3 with minecraft:arrow["minecraft:charged_projectiles":[{id:"minecraft:arrow"}],"minecraft:damage":290] 1
item replace block -2683 65 2278 container.4 with minecraft:arrow["minecraft:charged_projectiles":[{id:"minecraft:arrow"}],"minecraft:damage":60,"minecraft:enchantments":{"minecraft:quick_charge":1}] 1
item replace block -2683 65 2278 container.5 with minecraft:crossbow["minecraft:enchantments":{"nova_structures:power":4}] 1
item replace block -2683 65 2278 container.6 with minecraft:crossbow["minecraft:damage":411] 1
item replace block -2683 65 2278 container.7 with minecraft:crossbow["minecraft:custom_data":{mt:"weapon",weapon:"drylands_piercer"},"minecraft:custom_name":{color:"gold",italic:0b,text:"Пронзатель сухих земель"},"minecraft:enchantments":{"minecraft:piercing":7,"minecraft:quick_charge":3,"mt:weapons/drylands_piercer":1},"minecraft:lore":[" ",{color:"green",italic:0b,text:"Способность:"},{color:"gray",italic:0b,text:"Выстрелы наносят дополнительно 3 чистого "},{color:"gray",italic:0b,text:"урона, работает с ракетами. "}],"minecraft:repair_cost":99999,"minecraft:unbreakable":{}] 1
item replace block -2683 65 2278 container.8 with minecraft:crossbow["minecraft:damage":232,"minecraft:enchantments":{"enchantplus:sword/xp_boost":2,"minecraft:quick_charge":1}] 1
item replace block -2683 65 2278 container.9 with minecraft:crossbow["minecraft:damage":354] 1
item replace block -2683 65 2278 container.10 with minecraft:crossbow["minecraft:damage":3,"minecraft:enchantments":{"minecraft:quick_charge":2,"nova_structures:power":5}] 1
