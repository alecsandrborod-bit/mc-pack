# minecraft:decorated_pot на -2662 59 2265 — 1 слотов
item replace block -2662 59 2265 container.0 with minecraft:flower_pot 1
