# minecraft:chest на -2685 65 2278 — 5 слотов
item replace block -2685 65 2278 container.0 with minecraft:diamond_boots["minecraft:damage":195,"minecraft:enchantments":{"enchantplus:armor/fury":2},"minecraft:lore":[{color:"gray",text:"Нужно 75 Защита to use"}]] 1
item replace block -2685 65 2278 container.1 with minecraft:diamond_boots["minecraft:damage":46,"minecraft:enchantments":{"minecraft:mending":1,"minecraft:unbreaking":3}] 1
item replace block -2685 65 2278 container.2 with minecraft:diamond_boots["minecraft:damage":50,"minecraft:enchantments":{"nova_structures:traveler":2}] 1
item replace block -2685 65 2278 container.3 with minecraft:diamond_boots["minecraft:enchantments":{"minecraft:fire_protection":2,"nova_structures:traveler":2}] 1
item replace block -2685 65 2278 container.4 with minecraft:diamond_boots["minecraft:enchantments":{"minecraft:fire_protection":3}] 1
