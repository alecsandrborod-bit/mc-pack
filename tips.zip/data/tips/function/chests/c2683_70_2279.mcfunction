# minecraft:chest на -2683 70 2279 — 1 слотов
item replace block -2683 70 2279 container.0 with minecraft:chorus_fruit 3
