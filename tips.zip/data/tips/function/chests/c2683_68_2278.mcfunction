# minecraft:chest на -2683 68 2278 — 1 слотов
item replace block -2683 68 2278 container.0 with minecraft:totem_of_undying 12
