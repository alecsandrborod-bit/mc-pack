# Восстановление комнаты на -2664 59 2270 по журналу Ledger.
# Цель — состояние на 2026-08-31 12:00 UTC, то есть до сегодняшних откатов.
# Собрано скриптом из ledger.sqlite, руками не править.
#
# Сначала сносим то, что откат наплодил лишнего. Контейнеры ломаем
# с выпадением: их содержимое ляжет на пол, а не исчезнет.

setblock -2657 65 2278 minecraft:air replace
setblock -2671 61 2266 minecraft:air destroy
setblock -2672 61 2266 minecraft:air destroy
setblock -2671 61 2265 minecraft:air destroy
setblock -2672 61 2265 minecraft:air destroy
setblock -2670 61 2266 minecraft:air destroy
setblock -2668 61 2265 minecraft:air destroy
setblock -2670 61 2265 minecraft:air destroy
setblock -2669 61 2265 minecraft:air destroy
setblock -2665 61 2265 minecraft:air replace
setblock -2667 61 2265 minecraft:air destroy
setblock -2666 61 2265 minecraft:air destroy
setblock -2672 60 2266 minecraft:air destroy
setblock -2671 60 2266 minecraft:air destroy
setblock -2672 60 2265 minecraft:air destroy
setblock -2671 60 2265 minecraft:air destroy
setblock -2670 60 2266 minecraft:air destroy
setblock -2669 60 2265 minecraft:air destroy
setblock -2670 60 2265 minecraft:air destroy
setblock -2668 60 2265 minecraft:air destroy
setblock -2666 60 2265 minecraft:air destroy
setblock -2667 60 2265 minecraft:air destroy
setblock -2665 60 2265 minecraft:air replace
setblock -2664 60 2265 minecraft:air destroy
setblock -2663 60 2265 minecraft:air destroy
setblock -2671 59 2266 minecraft:air destroy
setblock -2672 59 2266 minecraft:air destroy
setblock -2671 59 2265 minecraft:air destroy
setblock -2672 59 2265 minecraft:air destroy
setblock -2670 59 2266 minecraft:air destroy
setblock -2668 59 2265 minecraft:air destroy
setblock -2670 59 2265 minecraft:air destroy
setblock -2669 59 2265 minecraft:air destroy
setblock -2665 59 2265 minecraft:air replace
setblock -2667 59 2265 minecraft:air destroy
setblock -2666 59 2265 minecraft:air destroy
setblock -2663 59 2265 minecraft:air destroy
setblock -2664 59 2265 minecraft:air destroy

# Теперь возвращаем то, что откат снёс: мебель комнаты и мелочь снаружи.
# Сундуки встают пустыми — их содержимое лежит рядом на полу.

setblock -2662 59 2267 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 59 2266 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 59 2268 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 59 2270 minecraft:crafting_table replace
setblock -2662 59 2269 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 59 2272 minecraft:waxed_copper_chest[facing=west,type=left,waterlogged=false] replace
setblock -2662 60 2266 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 60 2267 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 60 2269 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 60 2268 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 60 2270 minecraft:crafting_table replace
setblock -2662 60 2272 minecraft:waxed_copper_chest[facing=west,type=single,waterlogged=false] replace
setblock -2662 60 2271 minecraft:waxed_copper_chest[facing=west,type=right,waterlogged=false] replace
setblock -2662 61 2267 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 61 2266 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 61 2268 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 61 2270 minecraft:crafting_table replace
setblock -2662 61 2269 minecraft:furnace[facing=west,lit=false] replace
setblock -2662 62 2265 minecraft:lantern[hanging=true,waterlogged=false] replace
setblock -2677 67 2275 minecraft:grass_block replace
setblock -2677 67 2276 minecraft:grass_block replace
setblock -2676 67 2270 minecraft:grass_block replace
setblock -2662 69 2281 minecraft:grass_block replace
setblock -2677 69 2272 minecraft:grass_block replace
setblock -2659 69 2283 minecraft:short_grass replace
setblock -2662 70 2281 minecraft:gravel replace
setblock -2685 71 2279 minecraft:chipped_anvil[facing=south] replace
setblock -2687 72 2280 minecraft:spruce_trapdoor[facing=west,half=top,open=true,powered=false,waterlogged=false] replace

tellraw @s [{"text":"[Восстановление] ","color":"aqua"},{"text":"снесено лишнего: 38, возвращено: 28","color":"white"}]
