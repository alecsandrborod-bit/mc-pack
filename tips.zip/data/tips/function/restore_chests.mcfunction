# Наполняет пустые контейнеры содержимым по журналу Ledger.
# Двойной сундук считается одним хранилищем: содержимое обеих половин
# складывается и делится обратно, по 27 стопок на каждую.
# Непустые контейнеры не трогаются — у каждого вызова стоит проверка.

execute unless items block -2689 65 2267 container.* * run function tips:chests/c2689_65_2267
execute unless items block -2689 65 2268 container.* * run function tips:chests/c2689_65_2268
execute unless items block -2689 67 2268 container.* * run function tips:chests/c2689_67_2268
execute unless items block -2689 68 2268 container.* * run function tips:chests/c2689_68_2268
execute unless items block -2688 65 2267 container.* * run function tips:chests/c2688_65_2267
execute unless items block -2688 65 2268 container.* * run function tips:chests/c2688_65_2268
execute unless items block -2688 66 2267 container.* * run function tips:chests/c2688_66_2267
execute unless items block -2688 67 2267 container.* * run function tips:chests/c2688_67_2267
execute unless items block -2688 67 2268 container.* * run function tips:chests/c2688_67_2268
execute unless items block -2688 68 2268 container.* * run function tips:chests/c2688_68_2268
execute unless items block -2687 65 2268 container.* * run function tips:chests/c2687_65_2268
execute unless items block -2687 66 2267 container.* * run function tips:chests/c2687_66_2267
execute unless items block -2687 67 2268 container.* * run function tips:chests/c2687_67_2268
execute unless items block -2687 68 2268 container.* * run function tips:chests/c2687_68_2268
execute unless items block -2686 65 2267 container.* * run function tips:chests/c2686_65_2267
execute unless items block -2686 65 2268 container.* * run function tips:chests/c2686_65_2268
execute unless items block -2686 66 2268 container.* * run function tips:chests/c2686_66_2268
execute unless items block -2686 67 2268 container.* * run function tips:chests/c2686_67_2268
execute unless items block -2685 65 2267 container.* * run function tips:chests/c2685_65_2267
execute unless items block -2685 65 2268 container.* * run function tips:chests/c2685_65_2268
execute unless items block -2685 65 2278 container.* * run function tips:chests/c2685_65_2278
execute unless items block -2685 66 2268 container.* * run function tips:chests/c2685_66_2268
execute unless items block -2685 66 2278 container.* * run function tips:chests/c2685_66_2278
execute unless items block -2685 67 2268 container.* * run function tips:chests/c2685_67_2268
execute unless items block -2685 67 2278 container.* * run function tips:chests/c2685_67_2278
execute unless items block -2685 68 2268 container.* * run function tips:chests/c2685_68_2268
execute unless items block -2685 68 2278 container.* * run function tips:chests/c2685_68_2278
execute unless items block -2684 65 2267 container.* * run function tips:chests/c2684_65_2267
execute unless items block -2684 65 2278 container.* * run function tips:chests/c2684_65_2278
execute unless items block -2684 66 2278 container.* * run function tips:chests/c2684_66_2278
execute unless items block -2684 67 2278 container.* * run function tips:chests/c2684_67_2278
execute unless items block -2684 68 2278 container.* * run function tips:chests/c2684_68_2278
execute unless items block -2683 65 2268 container.* * run function tips:chests/c2683_65_2268
execute unless items block -2683 65 2278 container.* * run function tips:chests/c2683_65_2278
execute unless items block -2683 66 2278 container.* * run function tips:chests/c2683_66_2278
execute unless items block -2683 67 2278 container.* * run function tips:chests/c2683_67_2278
execute unless items block -2683 68 2278 container.* * run function tips:chests/c2683_68_2278
execute unless items block -2683 70 2279 container.* * run function tips:chests/c2683_70_2279
execute unless items block -2680 65 2271 container.* * run function tips:chests/c2680_65_2271
execute unless items block -2680 65 2272 container.* * run function tips:chests/c2680_65_2272
execute unless items block -2680 65 2273 container.* * run function tips:chests/c2680_65_2273
execute unless items block -2680 66 2272 container.* * run function tips:chests/c2680_66_2272
execute unless items block -2680 66 2273 container.* * run function tips:chests/c2680_66_2273
execute unless items block -2680 66 2274 container.* * run function tips:chests/c2680_66_2274
execute unless items block -2680 66 2275 container.* * run function tips:chests/c2680_66_2275
execute unless items block -2680 67 2272 container.* * run function tips:chests/c2680_67_2272
execute unless items block -2680 67 2274 container.* * run function tips:chests/c2680_67_2274
execute unless items block -2680 67 2275 container.* * run function tips:chests/c2680_67_2275
execute unless items block -2680 68 2278 container.* * run function tips:chests/c2680_68_2278
execute unless items block -2680 84 2274 container.* * run function tips:chests/c2680_84_2274
execute unless items block -2673 59 2265 container.* * run function tips:chests/c2673_59_2265
execute unless items block -2664 59 2265 container.* * run function tips:chests/c2664_59_2265
execute unless items block -2662 59 2265 container.* * run function tips:chests/c2662_59_2265
execute unless items block -2662 59 2271 container.* * run function tips:chests/c2662_59_2271
execute unless items block -2662 60 2266 container.* * run function tips:chests/c2662_60_2266
execute unless items block -2662 60 2271 container.* * run function tips:chests/c2662_60_2271
execute unless items block -2662 61 2266 container.* * run function tips:chests/c2662_61_2266
execute unless items block -2662 61 2271 container.* * run function tips:chests/c2662_61_2271

tellraw @s [{"text":"[Сундуки] ","color":"aqua"},{"text":"контейнеров: 58, слотов: 755","color":"white"}]
