# Копия svm_ep:player/ability_input/item/held.mcfunction без последней
# строки — там playsound block.beacon.deactivate, звук при уходе
# предмета ввода из основной руки, то есть буквально при каждом
# переключении хотбара. Датапак читается поверх мода, наша копия по
# этому пути побеждает. Держим здесь, а не в ru_override: тот собирается
# из джарника заново под перевод, и переживёт это только то, что там уже
# было на момент правки, — эта функция там и не появлялась, там нечего
# переводить, а поведенческие правки от переводов лучше не путать.
#
# ЕСЛИ МОД ОБНОВИТСЯ: сверить эту функцию с оригиналом в новом джарнике
# (data/svm_ep/function/player/ability_input/item/held.mcfunction) —
# вдруг автор поменял тут что-то ещё, кроме звука.
execute as @s[scores={input.using_item_time=1..}] run function svm_ep:player/ability_input/item/using_item/tick
execute as @s[scores={input.jump_time=1..}] run function svm_ep:player/ability_input/item/jump/tick
execute as @s[scores={input.sprint_time=1..}] run function svm_ep:player/ability_input/item/sprint/tick
execute unless items entity @s weapon.mainhand *[minecraft:custom_data~{svm_ep.item:{id:"input_item"}}] run function svm_ep:player/ability_input/item/no_mainhand

execute if items entity @s weapon.mainhand *[minecraft:custom_data~{svm_ep.item:{id:"input_item"}}] run return run advancement revoke @s only svm_ep:track_input_item
