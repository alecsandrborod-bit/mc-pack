tellraw @s ["",{"text":"\n\n\n\n\n"},{"text":"Битва с драконом Края","color":"dark_purple"},{"text":"\nМеню настроек"}]

execute if score MusicMode EDFR.config matches 1 run tellraw @s ["Music: ",{"click_event":{"action":"run_command","command":"/function endfight:config/music_off"},"color":"red","text":"[Выкл]"}," ",{"click_event":{"action":"run_command","command":"/function endfight:config/music_resource_pack"},"color":"green","text":"[Ресурспак]"}]
execute if score MusicMode EDFR.config matches 0 run tellraw @s ["Music: ",{"click_event":{"action":"run_command","command":"/function endfight:config/music_off"},"color":"green","text":"[Выкл]"}," ",{"click_event":{"action":"run_command","command":"/function endfight:config/music_resource_pack"},"color":"red","text":"[Ресурспак]"}]

tellraw @s ["Dragon Health: ",{"click_event":{"action":"run_command","command":"/function endfight:config/health_minus"},"color":"red","text":"-"}," ",{"score":{"name":"DragonHealth","objective":"EDFR.config"}}," ",{"click_event":{"action":"run_command","command":"/function endfight:config/health_add"},"color":"green","text":"+"}]
