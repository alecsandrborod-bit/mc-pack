tellraw @s [{"text":"<-----","color":"white","bold":true}]
tellraw @s [{"text":"0 — выключить, 1 — включить","color":"white","bold":true}]

function svm_ep:menu/powers

tellraw @s [{"text":"----->","color":"white","bold":true}]
