tellraw @s ["",{"text":"[","color":"gray"},{"text":"Mine","color":"white"},{"text":" сокровище","color":"gold"},{"text":"] ","color":"gray"},{"text":"Так не выйдет: возьмите зачаровываемый предмет во вторую руку!"}]

loot give @s loot mt:runes/knockchant