$execute as $(name) run function mt:treasure/player/update/rare

setblock ~ ~ ~ minecraft:barrel[facing=up]{LootTable:"mt:chests/end/rare",CustomName:{"text":"      Редкое сокровище Края","color":"blue","bold":false,"italic":false}} destroy

particle minecraft:nautilus ~ ~0.25 ~ 0.7 0.7 0.7 1 200
playsound minecraft:entity.enderman.death master @a[distance=..15] ~ ~ ~ 0.2 0.6 1
