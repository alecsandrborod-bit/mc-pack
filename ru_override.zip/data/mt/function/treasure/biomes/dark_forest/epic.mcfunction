$execute as $(name) run function mt:treasure/player/update/epic

setblock ~ ~ ~ minecraft:barrel[facing=up]{LootTable:"mt:chests/dark_forest/epic",CustomName:{"text":" Эпическое сокровище тёмного леса","color":"dark_red","bold":false,"italic":false}} destroy


particle minecraft:totem_of_undying ~ ~ ~ 1 1 1 0 20 force
particle minecraft:sweep_attack ~ ~ ~ 0.5 0.5 0.5 0 50 force
playsound minecraft:entity.ravager.death master @a[distance=..25] ~ ~ ~ 2 0.7 1
