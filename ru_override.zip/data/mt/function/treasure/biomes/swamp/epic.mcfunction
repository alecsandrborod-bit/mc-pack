$execute as $(name) run function mt:treasure/player/update/epic

setblock ~ ~ ~ minecraft:barrel[facing=up]{LootTable:"mt:chests/swamp/epic",CustomName:{"text":"   Эпическое сокровище болота","color":"dark_red","bold":false,"italic":false}} destroy


particle minecraft:wax_off ~ ~ ~ 0.5 0.5 0.5 0 100 force
particle minecraft:falling_obsidian_tear ~ ~ ~ 0.5 0.5 0.5 0 100 force
playsound minecraft:block.respawn_anchor.charge master @a[distance=..25] ~ ~ ~ 2 0.5 1
