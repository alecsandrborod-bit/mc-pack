$execute as $(name) run function mt:treasure/player/update/rare

setblock ~ ~ ~ minecraft:barrel[facing=up]{LootTable:"mt:chests/swamp/rare",CustomName:{"text":"     Редкое сокровище болота","color":"blue","bold":false,"italic":false}} destroy


particle minecraft:item_slime ~ ~ ~ 0.5 0.5 0.5 2 100
playsound minecraft:item.axe.wax_off master @a[distance=..15] ~ ~ ~ 2 0.1 1
