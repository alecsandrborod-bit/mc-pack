data merge storage mt:settings {\
  "4": [\
    { "id": "5", "display": { "text": "Гиперзвуковая", "type": "text" } },\
    { "id": "1", "display": { "text": "Черепашья", "type": "text" } },\
    { "id": "2", "display": { "text": "Медленная", "type": "text" } },\
    { "id": "3", "display": { "text": "Обычная", "type": "text" } },\
    { "id": "4", "display": { "text": "Быстрая", "type": "text" } }\
  ]\
}

data modify storage mt:settings despawn_speed set value 'hypersonic'
