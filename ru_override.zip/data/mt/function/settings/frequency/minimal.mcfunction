data merge storage mt:settings {\
  "2": [\
    { "id": "1", "display": { "text": "Минимальная", "type": "text" } },\
    { "id": "2", "display": { "text": "Низкая", "type": "text" } },\
    { "id": "3", "display": { "text": "Обычная", "type": "text" } },\
    { "id": "4", "display": { "text": "Высокая", "type": "text" } },\
    { "id": "5", "display": { "text": "Предельная", "type": "text" } }\
  ]\
}

execute store result score #chance_common mt.var run scoreboard players set #var mt.const 1000
execute store result score #chance_rare mt.var run scoreboard players set #var mt.const 250
execute store result score #chance_epic mt.var run scoreboard players set #var mt.const 40
execute store result score #chance_legendary mt.var run scoreboard players set #var mt.const 20
execute store result score #chance_mythical mt.var run scoreboard players set #var mt.const 5

function mt:settings/frequency/update_rates
