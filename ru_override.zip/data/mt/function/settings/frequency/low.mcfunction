data merge storage mt:settings {\
  "2": [\
    { "id": "2", "display": { "text": "Низкая", "type": "text" } },\
    { "id": "3", "display": { "text": "Обычная", "type": "text" } },\
    { "id": "4", "display": { "text": "Высокая", "type": "text" } },\
    { "id": "5", "display": { "text": "Предельная", "type": "text" } },\
    { "id": "1", "display": { "text": "Минимальная", "type": "text" } }\
  ]\
}

execute store result score #chance_common mt.var run scoreboard players set #var mt.const 2500
execute store result score #chance_rare mt.var run scoreboard players set #var mt.const 725
execute store result score #chance_epic mt.var run scoreboard players set #var mt.const 80
execute store result score #chance_legendary mt.var run scoreboard players set #var mt.const 40
execute store result score #chance_mythical mt.var run scoreboard players set #var mt.const 10

function mt:settings/frequency/update_rates
