data merge storage mt:settings {\
  "1": [\
    { "id": "4", "display": { "text": "Высокая", "type": "text" } },\
    { "id": "5", "display": { "text": "Предельная", "type": "text" } },\
    { "id": "1", "display": { "text": "Минимальная", "type": "text" } },\
    { "id": "2", "display": { "text": "Низкая", "type": "text" } },\
    { "id": "3", "display": { "text": "Обычная", "type": "text" } }\
  ]\
}

scoreboard players set #progression mt.var 600000
