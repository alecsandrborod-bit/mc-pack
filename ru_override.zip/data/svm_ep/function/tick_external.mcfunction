execute if score %running_svm_tick svm_ep.function matches 1 run tellraw @a[gamemode=creative] "Предыдущий такт не успел завершиться!"
scoreboard players set %running_svm_tick svm_ep.function 1
function svm_ep:tick
scoreboard players reset %running_svm_tick svm_ep.function
