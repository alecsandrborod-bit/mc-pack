#function svm_ep:menu/setup

data remove storage svm_ep:menu main
data modify storage svm_ep:menu main.title set value [{"text":" Меню сил SVM","color":"#4f4d4d"}]
data modify storage svm_ep:menu main.ability_points set value [{"text":"Очки способностей: ","color":"aqua"}]
data modify storage svm_ep:menu main.faq set value [{"text":"Вопросы и ответы","color":"#ff0834"}]
data modify storage svm_ep:menu main.player_and_stats set value [{"text":" Игрок и статистика","color":"#4f4d4d"}]
data modify storage svm_ep:menu main.power_info set value [{"text":"О силах","color":"#ff8107"}]
data modify storage svm_ep:menu main.items_info set value [{"text":"О предметах","color":"#56ff61"}]
data modify storage svm_ep:menu main.settings set value [{"text":"Настройки","color":"#c20618"}]
data modify storage svm_ep:menu main.discord set value [{"text":"Discord","color":"#4b2dff"}]

data remove storage svm_ep:menu faq
data modify storage svm_ep:menu faq.title set value [{"text":"Частые вопросы","color":"#ff092a"}]

data remove storage svm_ep:menu other
data modify storage svm_ep:menu other.power_perks_and_leveling set value [{"text":"Перки и уровни","color":"#ed12e5"}]
data modify storage svm_ep:menu other.power_ability_variants set value [{"text":"Варианты","color":"#52ffb7"}]
data modify storage svm_ep:menu other.power_ability_variants_description set value "Щёлкните, чтобы посмотреть варианты"


data modify storage svm_ep:menu other.upgrade_title set value [{"text":"⏶ Улучшить ⏶","color":"#3fff40"}]

data modify storage svm_ep:menu other.upgrades.0 set value {name:["Cooldown Reduction"],max:100,id:cooldown,progress_color:green}
data modify storage svm_ep:menu other.upgrades.1 set value {name:["Mana Cost Reduction"],max:100,id:cost,progress_color:aqua}


#THIS WILL BE REMIOVEd
#data remove storage svm_ep:menu power
#data modify storage svm_ep:menu power.title set value [{"text":"P",color:"#03ffb8"},{"text":"o",color:"#2dfec5"},{"text":"w",color:"#58fdd2"},{"text":"e",color:"#82fcdf"},{"text":"r",color:"#adfbec"},{"text":" ",color:"#d8fafa"},{"text":"I",color:"#a2fbe9"},{"text":"n",color:"#6dfcd9"},{"text":"f",color:"#38fdc8"},{"text":"o",color:"#03ffb8"}]
#THIS WILL BE REMIOVEd



#function #svm_ep:menu/setup_power
