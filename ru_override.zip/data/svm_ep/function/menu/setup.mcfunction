#function svm_ep:menu/setup

data remove storage svm_ep:menu main
data modify storage svm_ep:menu main.title set value [{"text":" ","color":"#4f4d4d"},{"text":"S","color":"#ff8706"},{"text":"V","color":"#ff9716"},{"text":"M","color":"#ffa727"},{"text":" ","color":"#ffb738"},{"text":"P","color":"#ffc748"},{"text":"o","color":"#ffd759"},{"text":"w","color":"#ffe76a"},{"text":"e","color":"#fff87b"},{"text":"r","color":"#ffe76a"},{"text":"s","color":"#ffd759"},{"text":" ","color":"#ffc748"},{"text":"M","color":"#ffb738"},{"text":"e","color":"#ffa727"},{"text":"n","color":"#ff9716"},{"text":"u","color":"#ff8706"}]
data modify storage svm_ep:menu main.ability_points set value [{"text":"Ab","color":"aqua"},{"text":"il","color":"#8FFFFF"},{"text":"it","color":"#CAFFFF"},{"text":"y Po","color":"#EEFFFF"},{"text":"in","color":"#CAFFFF"},{"text":"t","color":"#8FFFFF"},{"text":"s","color":"aqua"},{"text":": ","color":"gray"}]
data modify storage svm_ep:menu main.faq set value [{"text":"F","color":"#ff0834"},{"text":"A","color":"#ff0652"},{"text":"Q","color":"#ff0834"}]
data modify storage svm_ep:menu main.player_and_stats set value [{"text":" ","color":"#4f4d4d"},{"text":"P","color":"#36d304"},{"text":"l","color":"#52d81f"},{"text":"a","color":"#6fde3a"},{"text":"y","color":"#8ce456"},{"text":"e","color":"#a8ea71"},{"text":"r","color":"#c5f08d"},{"text":" ","color":"#e2f6a8"},{"text":"&","color":"#fffcc4"},{"text":" ","color":"#ddf5a4"},{"text":"S","color":"#bcee84"},{"text":"t","color":"#9ae764"},{"text":"a","color":"#79e044"},{"text":"t","color":"#57d924"},{"text":"s","color":"#36d304"}]
data modify storage svm_ep:menu main.power_info set value [{"text":"P","color":"#ff8107"},{"text":"o","color":"#ff9617"},{"text":"w","color":"#ffab27"},{"text":"e","color":"#ffc137"},{"text":"r","color":"#ffd647"},{"text":" ","color":"#ffec58"},{"text":"I","color":"#ffd143"},{"text":"n","color":"#ffb62f"},{"text":"f","color":"#ff9b1b"},{"text":"o","color":"#ff8107"}]
data modify storage svm_ep:menu main.items_info set value [{"text":"I","color":"#56ff61"},{"text":"t","color":"#76fe7f"},{"text":"e","color":"#97fd9e"},{"text":"m","color":"#b8fcbc"},{"text":"s","color":"#d9fbdb"},{"text":" ","color":"#fafafa"},{"text":"I","color":"#d1fbd3"},{"text":"n","color":"#a8fcad"},{"text":"f","color":"#7ffd87"},{"text":"o","color":"#56ff61"}]
data modify storage svm_ep:menu main.settings set value [{"text":"S","color":"#c20618"},{"text":"e","color":"#d11f27"},{"text":"t","color":"#e03837"},{"text":"t","color":"#ef5147"},{"text":"i","color":"#ff6a57"},{"text":"n","color":"#ea4842"},{"text":"g","color":"#d6272d"},{"text":"s","color":"#c20618"}]
data modify storage svm_ep:menu main.discord set value [{"text":"D","color":"#4b2dff"},{"text":"i","color":"#684cff"},{"text":"s","color":"#866cff"},{"text":"c","color":"#a48cff"},{"text":"o","color":"#c2acff"},{"text":"r","color":"#866cff"},{"text":"d","color":"#4b2dff"}]

data remove storage svm_ep:menu faq
data modify storage svm_ep:menu faq.title set value [{"text":"F","color":"#ff092a"},{"text":"r","color":"#ff1b38"},{"text":"e","color":"#ff2d46"},{"text":"q","color":"#ff3f54"},{"text":"u","color":"#ff5162"},{"text":"e","color":"#ff6370"},{"text":"n","color":"#ff757e"},{"text":"t","color":"#ff878c"},{"text":"l","color":"#ff999a"},{"text":"y","color":"#ffaba8"},{"text":" ","color":"#ffbdb6"},{"text":"A","color":"#ffcfc4"},{"text":"s","color":"#ffe1d2"},{"text":"k","color":"#fff3e0"},{"text":"e","color":"#ffdfd0"},{"text":"d","color":"#ffccc1"},{"text":" ","color":"#ffb8b2"},{"text":"Q","color":"#ffa5a3"},{"text":"u","color":"#ff9194"},{"text":"e","color":"#ff7e85"},{"text":"s","color":"#ff6a75"},{"text":"t","color":"#ff5766"},{"text":"i","color":"#ff4357"},{"text":"o","color":"#ff3048"},{"text":"n","color":"#ff1c39"},{"text":"s","color":"#ff092a"}]

data remove storage svm_ep:menu other
data modify storage svm_ep:menu other.power_perks_and_leveling set value [{"text":"P","color":"#ed12e5"},{"text":"e","color":"#ee2ce7"},{"text":"r","color":"#f046ea"},{"text":"k","color":"#f160ec"},{"text":"s","color":"#f37bef"},{"text":" ","color":"#f595f2"},{"text":"&","color":"#f6aff4"},{"text":" ","color":"#f8c9f7"},{"text":"L","color":"#fae4fa"},{"text":"e","color":"#d7dff4"},{"text":"v","color":"#b4daee"},{"text":"e","color":"#91d5e8"},{"text":"l","color":"#6ed1e2"},{"text":"i","color":"#4bccdc"},{"text":"n","color":"#28c7d6"},{"text":"g","color":"#05c3d1"}]
data modify storage svm_ep:menu other.power_ability_variants set value [{"text":"V","color":"#52ffb7"},{"text":"a","color":"#70ffc3"},{"text":"r","color":"#8fffcf"},{"text":"i","color":"#aeffdb"},{"text":"a","color":"#cdffe8"},{"text":"n","color":"#a4ffd7"},{"text":"t","color":"#7bffc7"},{"text":"s","color":"#52ffb7"}]
data modify storage svm_ep:menu other.power_ability_variants_description set value "Щёлкните, чтобы посмотреть варианты"


data modify storage svm_ep:menu other.upgrade_title set value [{"text":"⏶","color":"#3fff40"},{"text":" ","color":"#5aff54"},{"text":"U","color":"#75ff68"},{"text":"p","color":"#90ff7c"},{"text":"g","color":"#abff90"},{"text":"r","color":"#c6ffa4"},{"text":"a","color":"#e1ffb9"},{"text":"d","color":"#b8ff9a"},{"text":"e","color":"#90ff7c"},{"text":" ","color":"#67ff5e"},{"text":"⏶","color":"#3fff40"}]

data modify storage svm_ep:menu other.upgrades.0 set value {name:["Cooldown Reduction"],max:100,id:cooldown,progress_color:green}
data modify storage svm_ep:menu other.upgrades.1 set value {name:["Mana Cost Reduction"],max:100,id:cost,progress_color:aqua}


#THIS WILL BE REMIOVEd
#data remove storage svm_ep:menu power
#data modify storage svm_ep:menu power.title set value [{"text":"P",color:"#03ffb8"},{"text":"o",color:"#2dfec5"},{"text":"w",color:"#58fdd2"},{"text":"e",color:"#82fcdf"},{"text":"r",color:"#adfbec"},{"text":" ",color:"#d8fafa"},{"text":"I",color:"#a2fbe9"},{"text":"n",color:"#6dfcd9"},{"text":"f",color:"#38fdc8"},{"text":"o",color:"#03ffb8"}]
#THIS WILL BE REMIOVEd



#function #svm_ep:menu/setup_power