title @s times 10t 2s 10t
execute if items entity @s weapon.mainhand * run title @s title {"text":"Основная рука должна быть пуста!"}
execute if items entity @s weapon.mainhand * run return 0


summon item_display ~ ~ ~ {Tags:["svm_ep.temporary_storage"]}
loot replace entity @n[tag=svm_ep.temporary_storage] contents loot svm_ep:items/ability_input/default
data remove storage svm_ep:data temp
execute as @s[scores={svm_ep.menu=33}] run function svm_ep:system/power/select_power
execute as @s[scores={svm_ep.menu=33}] run function svm_ep:menu/settings/ability_input/from_power with storage svm_ep:data temp



item replace entity @s weapon.mainhand from entity @n[tag=svm_ep.temporary_storage] contents
kill @e[tag=svm_ep.temporary_storage]
return 1