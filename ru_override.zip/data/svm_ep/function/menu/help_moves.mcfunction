#THIS WILL 
execute as @s[tag=!svm_ep.power_user] run return run dialog show @s {type:"minecraft:notice",title:[{text:" ",color:"#4f4d4d"},{text:"P",color:"#03ffb8"},{text:"o",color:"#2dfec5"},{text:"w",color:"#58fdd2"},{text:"e",color:"#82fcdf"},{text:"r",color:"#adfbec"},{text:" ",color:"#d8fafa"},{text:"I",color:"#a2fbe9"},{text:"n",color:"#6dfcd9"},{text:"f",color:"#38fdc8"},{text:"o",color:"#03ffb8"}],body:{type:"minecraft:item",item:{id:"minecraft:barrier"},description:{text:"Получите силу, чтобы увидеть её способности!"},show_decorations:0b,show_tooltip:0b,height:16},can_close_with_escape:1b,pause:1b}

function svm_ep:system/power/select_power
function svm_ep:menu/moves/dialog with storage svm_ep:data temp