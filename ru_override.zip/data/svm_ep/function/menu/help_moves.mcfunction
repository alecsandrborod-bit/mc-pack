#THIS WILL 
execute as @s[tag=!svm_ep.power_user] run return run dialog show @s {type:"minecraft:notice",title:[{"text":"О силах","color":"#4f4d4d"}],body:{type:"minecraft:item",item:{id:"minecraft:barrier"},description:{text:"Obtain a power to see its abilities!"},show_decorations:0b,show_tooltip:0b,height:16},can_close_with_escape:1b,pause:1b}

function svm_ep:system/power/select_power
function svm_ep:menu/moves/dialog with storage svm_ep:data temp