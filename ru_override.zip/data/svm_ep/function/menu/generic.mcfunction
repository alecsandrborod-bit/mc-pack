$execute at @s run dialog show @s {type:"minecraft:multi_action",title:$(title),body:[{type:"minecraft:item",item:{id:"minecraft:amethyst_cluster",components:{"minecraft:item_model":"svm_ep:gui/big_icon"}},show_decorations:0,show_tooltip:0},{type:"minecraft:plain_message",contents:""},{type:"minecraft:plain_message",contents:""},{type:"minecraft:plain_message",contents:""}],after_action:"wait_for_response",columns:1,actions:[\
{label:$(faq),tooltip:"Самое нужное вкратце",width:150,action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 3"}},\
{label:$(player_and_stats),tooltip:"Посмотреть свою статистику",width:150,action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 6"}},\
{label:$(power_info),tooltip:"Сведения о силах и открытие способностей",width:150,action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 4"}},\
{label:$(items_info),tooltip:"Сведения о предметах",width:150,action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 5"}},\
{label:$(discord),tooltip:"https://discord.gg/3Ku2mDtTtv",width:150,action:{type:"minecraft:open_url",url:"https://discord.gg/3Ku2mDtTtv"}},\
{label:$(settings),tooltip:"Изменить настройки",width:150,action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 10"}},\
{width:1,label:"",action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 2"}},\
{width:1,label:"",action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 2"}},\
{label:{text:"Выход",color:"#db0000"},action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 2"}}\
]}

execute at @s run playsound minecraft:entity.villager.work_shepherd ui @s ~ ~ ~ 0.5 0.8
execute at @s run playsound minecraft:entity.iron_golem.repair ui @s ~ ~ ~ 0.5 0.8






return 0
#OLD

tellraw @s ["",{"text":"| Меню\n| ","color":"gray"},{"selector":"@s","bold":true}]
tellraw @s ["",{"text":"| Очки способностей: [","color":"gray"},{"score":{"name":"@s","objective":"svm_ep.ability_points"},"color":"red"},{"text":"]","color":"gray"}]


tellraw @s [{"text":"|","color":"gray"}]
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Настройки","color":"red","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 10"}},{"text":"]","color":"gray"}]
tellraw @s [{"text":"|","color":"gray"}]

tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Краткое обучение","bold":true,"color":"red","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 3"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы открыть частые вопросы"}},{"text":"]","color":"gray"}]
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Discord","bold":true,"color":"#8460FF","click_event":{"action":"open_url","url":"https://discord.gg/3Ku2mDtTtv"},"hover_event":{"action":"show_text","value":"https://discord.gg/3Ku2mDtTtv"}},{"text":"]","color":"gray"}]
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"О предметах","bold":true,"color":"#30FBFD","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 5"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть сведения о предметах"}},{"text":"]","color":"gray"}]
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"О силах","bold":true,"color":"#1FFF1C","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 4"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть сведения о нынешней силе"}},{"text":"]","color":"gray"}]
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Внешний вид","bold":true,"color":"yellow","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 6"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть и настроить внешний вид"}},{"text":"]","color":"gray"}]





#tellraw @s [{"text":"<-----","color":"white","bold":true}]
#tellraw @s [{"text":"----->","color":"white","bold":true}]
#tellraw @s ["",{"text":"| ","color":"gray"},{"text":"M","color":"gold"},{"text":"a","color":"#FFBD30"},{"text":"x ma","color":"#FFD75B"},{"text":"n","color":"#FFBD30"},{"text":"a","color":"gold"},{"text":": ","color":"gray"},{"score":{"name":"@s","objective":"svm_ep.mana_max"},"color":"aqua"}]
#tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Mo","color":"gold"},{"text":"b ","color":"#FFB927"},{"text":"ki","color":"#FFD157"},{"text":"ll","color":"#FFB927"},{"text":"s","color":"gold"},{"text":": [","color":"gray"},{"score":{"name":"@s","objective":"svm_ep.souls"},"color":"#FFD860"},{"text":"]","color":"gray"}]
#tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Dea","color":"gold"},{"text":"th ","color":"#FFB927"},{"text":"Cou","color":"#FFD157"},{"text":"n","color":"#FFB927"},{"text":"t","color":"gold"},{"text":": [","color":"gray"},{"score":{"name":"@s","objective":"svm_ep.deaths"},"color":"#FFD860"},{"text":"]","color":"gray"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"T","bold":true,"color":"#EB4EFF","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 8"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть свой талант"}},{"text":"a","bold":true,"color":"#F56BFF","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 8"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть свой талант"}},{"text":"l","bold":true,"color":"#FB96FF","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 8"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть свой талант"}},{"text":"e","bold":true,"color":"#FEA8FF","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 8"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть свой талант"}},{"text":"n","bold":true,"color":"#FB96FF","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 8"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть свой талант"}},{"text":"t","bold":true,"color":"#F56BFF","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 8"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть свой талант"}},{"text":"s","bold":true,"color":"#EB4EFF","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 8"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть свой талант"}},{"text":"]","color":"gray"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"M","bold":true,"color":"#AD38F8","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 9"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть своё чудо"}},{"text":"iracl","bold":true,"color":"#B54EFF","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 9"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть своё чудо"}},{"text":"e","bold":true,"color":"#AD38F8","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 9"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть своё чудо"}},{"text":"]","color":"gray"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"B","bold":true,"color":"#BEF84C","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 7"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть своё благословение"}},{"text":"l","bold":true,"color":"#DBFF72","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 7"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть своё благословение"}},{"text":"essin","bold":true,"color":"#EEFF8F","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 7"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть своё благословение"}},{"text":"g","bold":true,"color":"#DBFF72","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 7"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть своё благословение"}},{"text":"s","bold":true,"color":"#BEF84C","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 7"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы посмотреть своё благословение"}},{"text":"]","color":"gray"}]
