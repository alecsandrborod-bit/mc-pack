data remove storage svm_ep:menu temp
data merge storage svm_ep:menu {temp:{ability_input:"$(ability_input)",give_ability_input:"$(give_ability_input)"}}

scoreboard players operation %temp svm_ep.numbers = @s input.selected_slot
scoreboard players add %temp svm_ep.numbers 1
execute store result storage svm_ep:menu temp.selected_slot_id_plus_1 int 1.0 run scoreboard players get %temp svm_ep.numbers

data merge storage svm_ep:menu {temp:{ability_input_initial0:true,ability_input_initial1:false,give_ability_input_initial:true}}
execute as @s[scores={svm_ep.ability_input=1}] run data merge storage svm_ep:menu {temp:{ability_input_initial1:true,ability_input_initial0:false}}
execute as @s[scores={svm_ep.give_ability_item=0}] run data modify storage svm_ep:menu temp.give_ability_input_initial set value 0


function svm_ep:menu/settings/display with storage svm_ep:menu temp

# ARGS
#  $(ability_input_initial0) $(ability_input_initial1) $(give_ability_input_initial) $(selected_slot_id_plus_1)
# TO BE PRESERVED
# $(ability_input) $(give_ability_input)



return 0
tellraw @s {"text":"|","color":"gray"}
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Привязать меню","color":"#FF9DD0","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 9999"}},{"text":"]","color":"gray"}]
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Привязать переключение сил","color":"aqua","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 9998"}},{"text":"]","color":"gray"}]
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Отвязать слот","color":"#FF4988","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 10000"}},{"text":"]","color":"gray"}]
#tellraw @s ["",{"text":"| Сохранить панель в слот: [","color":"gray"},{"text":" 1 ","color":"green","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 11"}},{"text":"] [","color":"gray"},{"text":" 2 ","color":"red","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 12"}},{"text":"]","color":"gray"}]
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Привязать переключение слотов","color":"#5198CC","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 9997"}},{"text":"]","color":"gray"}]

tellraw @s ["",{"text":"| Расход способности [","color":"gray"},{"text":"Правый клик","color":"yellow","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 3001"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы применять способности правым кликом по предмету «Применить способность»"}},{"text":"] [","color":"gray"},{"text":"Shift + клик","color":"red","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 3000"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы применять способности через Shift"}},{"text":"]","color":"gray"}]




tellraw @a ["",{"text":"| Выдаётся предмет «Применить способность» [","color":"gray"},{"text":"ON","color":"green","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 3002"},"hover_event":{"action":"show_text","value":"ON"}},{"text":"] [","color":"gray"},{"text":"ВЫКЛ","color":"red","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 3003"},"hover_event":{"action":"show_text","value":"ВЫКЛ"}},{"text":"]","color":"gray"}]
tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Обновить предмет","color":"dark_red","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 31"},"hover_event":{"action":"show_text","value":"Обновляет предмет из старых версий; облик при этом не меняется"}},{"text":"]","color":"gray"}]
