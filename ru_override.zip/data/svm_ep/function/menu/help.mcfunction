$dialog show @s {type:"minecraft:multi_action",title:$(title),body:[\
{type:"minecraft:plain_message",contents:{text:"Наведите на вопрос, чтобы увидеть ответ!",color:"#c4c4c4"}},\
{type:"minecraft:item",item:{id:"minecraft:gold_ingot",components:{"minecraft:item_model":"svm_ep:golden/flesh"}},description:{text:"Как получить силы?",bold:1,hover_event:{action:"show_text",value:{text:"Съешьте Золотую плоть (падает с зомби, у зомби с силами чаще). Свитки сил можно и создать — рецепты в меню предметов"}}},show_decorations:0,show_tooltip:0},\
{type:"minecraft:item",item:{id:"minecraft:flower_banner_pattern"},description:{text:"Как открывать способности?",bold:1,hover_event:{action:"show_text",value:{text:"Меню → О силах, выберите способность и нажмите [Открыть]"}}},show_decorations:0,show_tooltip:0},\
{type:"minecraft:item",item:{id:"minecraft:experience_bottle"},description:{text:"Как получить очки способностей?",bold:1,hover_event:{action:"show_text",value:{text:"Выполняйте достижения SVM Powers, ешьте Золотую плоть, владея силой, или поднимайте её уровень"}}},show_decorations:0,show_tooltip:0},\
{type:"minecraft:item",item:{id:"minecraft:spider_eye",components:{"minecraft:item_model":"svm_ep:golden/eye"}},description:{text:"Как увеличить запас маны?",bold:1,hover_event:{action:"show_text",value:{text:"Ешьте Золотые глаза, что падают с пауков и пещерных пауков"}}},show_decorations:0,show_tooltip:0},\
{type:"minecraft:item",item:{id:"minecraft:flower_banner_pattern",components:{"minecraft:item_model":"svm_ep:power_reseter"}},description:{text:"Как сменить силу?",bold:1,hover_event:{action:"show_text",value:{text:"Создайте Сброс силы и возьмите во вторую руку (рецепт в меню предметов) — тогда можно взять другую силу"}}},show_decorations:0,show_tooltip:0},\
{type:"minecraft:item",item:{id:"minecraft:flower_banner_pattern",components:{"minecraft:item_model":"minecraft:nether_star"}},description:{text:"Как поднять уровень силы?",bold:1,hover_event:{action:"show_text",value:{text:"Уровень силы растёт сам, пока вы тратите ману. Полоса прогресса — в меню, раздел «Игрок и статистика»"}}},show_decorations:0,show_tooltip:0}\
],can_close_with_escape:1,after_action:"wait_for_response",actions:[{label:{text:"Главное меню",color:"#db0000"},width:70,action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 1"}}]}





return 0

tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Наведите на вопрос, чтобы увидеть ответ","bold":true,"color":"white"},{"text":"!","color":"gray"}]
tellraw @s ["",{"text":"| ","color":"gray"}]



tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Q","bold":true,"color":"aqua"},{"text":" - ","color":"gray"},{"text":"Как получить силы?","hover_event":{"action":"show_text","value":"Съешьте Золотую плоть (падает с зомби, у зомби с силами чаще). Свитки сил можно и создать — рецепты в меню предметов"}}]
tellraw @s ["",{"text":"| ","color":"gray"}]
tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Q","bold":true,"color":"aqua"},{"text":" - ","color":"gray"},{"text":"Как открывать способности?","hover_event":{"action":"show_text","value":"Откройте меню → О силах, выберите нужную силу и нажмите [Открыть], чтобы получить заслуженную способность"}}]
tellraw @s ["",{"text":"| ","color":"gray"}]
tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Q","bold":true,"color":"aqua"},{"text":" - ","color":"gray"},{"text":"Как получить очки способностей?","hover_event":{"action":"show_text","value":"Выполняйте достижения SVM Powers — и с силой в руках сможете есть Золотую плоть"}}]
tellraw @s ["",{"text":"| ","color":"gray"}]
tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Q","bold":true,"color":"aqua"},{"text":" - ","color":"gray"},{"text":"Как увеличить запас маны?","hover_event":{"action":"show_text","value":"Ешьте Золотые глаза, что падают с пауков и пещерных пауков"}}]
tellraw @s ["",{"text":"| ","color":"gray"}]
tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Q","bold":true,"color":"aqua"},{"text":" - ","color":"gray"},{"text":"Как сменить силу?","hover_event":{"action":"show_text","value":"Создайте Сброс силы и возьмите во вторую руку (рецепт в меню предметов)"}}]


#tellraw @s ["",{"text":"| ","color":"gray"}]
#tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Q","bold":true,"color":"aqua"},{"text":" - ","color":"gray"},{"text":"Как сменить силу?","hover_event":{"action":"show_text","value":"Создайте Сброс силы и возьмите во вторую руку (рецепт в меню предметов)"}}]


tellraw @s ["",{"text":"| ","color":"gray"}]
tellraw @s ["",{"text":"| ","color":"gray"},{"text":"Наведите на вопрос, чтобы увидеть ответ","bold":true,"color":"white"},{"text":"!","color":"gray"}]
tellraw @s [{"text":"|\n| ","color":"gray"},{"text":"Остались вопросы? Заходите в Discord и спрашивайте :)"}]




