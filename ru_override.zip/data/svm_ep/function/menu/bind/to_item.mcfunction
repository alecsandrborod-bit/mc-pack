#WE HAVE NUMBER LIKE 11, then the slot is the % 10 - 1 of the value (here will be 0), then ability id is value / 10 so here 1

#so this will bind 1 to slot 0

execute store result score %is_sneak svm_ep.numbers if score @s svm_ep.z.bind_ability.to_item matches ..-1
execute if score @s svm_ep.z.bind_ability.to_item matches ..-1 run scoreboard players operation @s svm_ep.z.bind_ability.to_item *= %-1 svm_ep.numbers
scoreboard players operation %slot svm_ep.numbers = @s svm_ep.z.bind_ability.to_item
scoreboard players operation %slot svm_ep.numbers %= %10 svm_ep.numbers

scoreboard players operation %id svm_ep.numbers = @s svm_ep.z.bind_ability.to_item
scoreboard players operation %id svm_ep.numbers /= %10 svm_ep.numbers
scoreboard players reset @s svm_ep.z.bind_ability.to_item
scoreboard players enable @s svm_ep.z.bind_ability.to_item



execute unless items entity @s weapon.mainhand *[minecraft:custom_data~{svm_ep.item:{id:"input_item"}}] run return run tellraw @s "Нужен предмет ввода — выдать его можно в настройках"
summon minecraft:item_display ~ ~ ~ {Tags:["svm_ep.temporary_storage"]}
item replace entity @n[tag=svm_ep.temporary_storage] contents from entity @s weapon.mainhand
data remove storage svm_ep:data temp
function svm_ep:system/power/select_power

execute as @n[tag=svm_ep.temporary_storage] run function svm_ep:menu/bind/to_item_0modify

item replace entity @s weapon.mainhand from entity @n[tag=svm_ep.temporary_storage] contents



kill @n[tag=svm_ep.temporary_storage]
function svm_ep:player/ability_input/item/start_holding