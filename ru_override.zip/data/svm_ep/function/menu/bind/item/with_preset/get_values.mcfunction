$execute unless data storage svm_ep:menu power.$(power).ability_preset run return run tellraw @s "У этой силы нет заготовки способностей"
$data modify storage svm_ep:data temp2.preset set from storage svm_ep:menu power.$(power).ability_preset

scoreboard players set %is_sneak svm_ep.numbers 0
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:1}
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:2}
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:3}
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:4}
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:5}
scoreboard players set %is_sneak svm_ep.numbers 1
data modify storage svm_ep:data temp2.preset set from storage svm_ep:data temp2.preset.sneak
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:1}
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:2}
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:3}
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:4}
function svm_ep:menu/bind/item/with_preset/get_values2 {slot:5}