data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/time'
data modify storage svm_ep:menu power.temp.description set value "Сила править самим ходом времени. Что ещё нужно?"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Time Stop","use_requirement":"Нужно 25 маны, накопление тратит","description":"Останавливает время вокруг","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Ускорение","use_requirement":"Нужно 45 маны","description":"Ускоряет все ваши действия","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Time Skip","use_requirement":"Нужно 25 маны","description":"Перескакивает на несколько секунд вперёд, подгоняя ману, перезарядки и прочее","id_number":3,"advancement_id":3,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Timestamp","use_requirement":"Нужно 50 маны","description":"Отмечает место и возвращает вас туда со второго применения; удержание сбрасывает метку","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:25}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Rewind","use_requirement":"Нужно 250 маны","description":"Возвращает существ вокруг туда, где они были некоторое время назад","id_number":5,"advancement_id":5,upgrades:[{},{}],unlock_cost:50}}
