data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/time'
data modify storage svm_ep:menu power.temp.description set value "Power that directly let's you manipulate the timeline, who would need anything more?"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Time Stop","use_requirement":"Requires 25 mana, charging drains","description":"Останавливает время вокруг","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Accelerate","use_requirement":"Requires 45 mana","description":"Ускоряет все ваши действия","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Time Skip","use_requirement":"Requires 25 mana","description":"Перескакивает на несколько секунд вперёд, подгоняя ману, перезарядки и прочее","id_number":3,"advancement_id":3,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Timestamp","use_requirement":"Requires 50 mana","description":"Отмечает место и возвращает вас туда со второго применения; удержание сбрасывает метку","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:25}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Rewind","use_requirement":"Requires 250 mana","description":"Возвращает существ вокруг туда, где они были некоторое время назад","id_number":5,"advancement_id":5,upgrades:[{},{}],unlock_cost:50}}
