data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/phase'
data modify storage svm_ep:menu power.temp.description set value "The power to completely avoid physical boundaries along with incoming damage. Cheap yet powerful, somebody great must have developed those!"



#REGISTER ABILITIES
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Быстрая фаза","use_requirement":"Нужно 20 маны","description":"Позволяет проходить сквозь стены и даёт неуязвимость ненадолго","id_number":7,"advancement_id":1,upgrades:[{cost:{type:item,item:"stone",count:"1",name:"Stone"}},{}],unlock_cost:{type:item,item:"stone",count:"1",name:"Stone"}}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Фаза","use_requirement":"Нужно 40 маны","description":"Позволяет проходить сквозь стены и даёт неуязвимость на приличное время","id_number":8,"advancement_id":2,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Полная фаза","use_requirement":"Requires 80 mana","description":"Позволяет проходить сквозь стены и даёт неуязвимость надолго","id_number":9,"advancement_id":3,upgrades:[{},{}],unlock_cost:5}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Ясный взор","use_requirement":"Нужно 50 маны","description":"На время очищает взор во время фазы","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:5}}



#TEMPLATE FOR CHAT GPT TO HELP UPDATE
#OLD(example without unlocking)
#tellraw @s [{"text":"| ","color":"gray"},{"text":"Быстрая фаза ","color":"yellow","hover_event":{"action":"show_text","value":""}},{"text":"- ","color":"gray"},{"text":" [Привязать]","color":"#F4D5FF","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 7"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы привязать к выбранному слоту"}}]
#NEW
#function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Быстрая фаза","use_requirement":"Нужно 5 маны","description":"Позволяет проходить сквозь стены и даёт неуязвимость ненадолго","id_number":7,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}


#OLD(example with unlocking)
#tellraw @s [{"text":"| ","color":"gray"},{"text":"Фаза ","color":"yellow","hover_event":{"action":"show_text","value":""}},{"text":"- Нужно 20 маны","color":"gray"},{"text":" [Привязать]","color":"#F4D5FF","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 8"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы привязать к выбранному слоту"}},{"text":" [Открыть]","color":"#8fffef","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 20002"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы открыть за 10 очков способностей"}}]
#NEW
#function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Фаза","use_requirement":"Нужно 20 маны","description":"Позволяет проходить сквозь стены и даёт неуязвимость на приличное время","id_number":8,"unlock_id":"20002","unlock_requirement":"Click to unlock for 10 Ability Points"}



#TO UPDATE
#tellraw @s [{"text":"| ","color":"gray"},{"text":"Полная фаза ","color":"yellow","hover_event":{"action":"show_text","value":"Позволяет проходить сквозь стены и даёт неуязвимость надолго"}},{"text":"- Нужно 40 маны","color":"gray"},{"text":" [Привязать]","color":"#F4D5FF","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 9"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы привязать к выбранному слоту"}},{"text":" [Открыть]","color":"#8fffef","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 20003"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы открыть за 15 очков способностей"}}]
#tellraw @s [{"text":"| ","color":"gray"},{"text":"Ясный взор ","color":"yellow","hover_event":{"action":"show_text","value":"На время очищает взор во время фазы"}},{"text":"- Нужно 50 маны","color":"gray"},{"text":" [Привязать]","color":"#F4D5FF","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 4"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы привязать к выбранному слоту"}},{"text":" [Открыть]","color":"#8fffef","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 20047"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы открыть за 20 очков способностей"}}]
