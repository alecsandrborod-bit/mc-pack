data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/snow'
data modify storage svm_ep:menu power.temp.description set value "Let some light in :))"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Snow Creation","use_requirement":"Toggleable, activated drains","description":"Делает вас неуязвимым!","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Clear Snow","use_requirement":"Requires 30 mana","description":"Стряхивает снег с существ и их снаряжения","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:5}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Manipulation","use_requirement":"Requires 50 mana","description":"Делает существ невидимыми, пока они рядом с носителем силы Снега","id_number":3,"advancement_id":3,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Snow Launcher","use_requirement":"Requires 10 mana for each mob","description":"Позволяет сделать невидимым предмет или снаряжение — например, седло","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Blizzard","use_requirement":"Requires 10 mana for each mob","description":"Позволяет сделать невидимым предмет или снаряжение — например, седло","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:15}}
#function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Hide Items","use_requirement":"Requires 10 mana for each mob","description":"Позволяет сделать предмет невидимым","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:15}}
