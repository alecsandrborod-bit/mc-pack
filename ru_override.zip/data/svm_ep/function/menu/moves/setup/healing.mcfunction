data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/healing'
data modify storage svm_ep:menu power.temp.description set value "Сила поддержки — только не забывайте поддержать и себя"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Исцелить","use_requirement":"Нужно 25 маны, накопление тратит","description":"Лечит вас; удержание лечит того, кто впереди","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Аура восстановления","use_requirement":"Нужно 60 маны","description":"Даёт регенерацию существам вокруг; удержание поднимает поле восстановления","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:5}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Метка","use_requirement":"Нужно 0 маны","description":"Ставит или снимает метку с существа впереди; удержание убирает прежнюю","id_number":3,"advancement_id":3,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Раздача здоровья","use_requirement":"Нужно 10 маны за каждое существо","description":"Посылает исцеляющий шар каждому помеченному существу","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Рука помощи","use_requirement":"Нужно 15 маны за каждое существо","description":"Посылает восстанавливающий шар каждому помеченному существу","id_number":5,"advancement_id":5,upgrades:[{},{}],unlock_cost:25}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Бессмертие","use_requirement":"Нужно 250 маны","description":"Сильно исцеляет каждый раз, когда вам наносят урон","id_number":6,"advancement_id":6,upgrades:[{},{}],unlock_cost:175}}
