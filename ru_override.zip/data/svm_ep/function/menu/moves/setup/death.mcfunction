data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/death'
data modify storage svm_ep:menu power.temp.description set value "It's been too lively recently..."


# Summon Scythe
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Summon Scythe","use_requirement":"Requires 25 mana, charging drains","description":"Даёт мощную косу","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}

# Life Drain
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Life Drain","use_requirement":"Requires 40 mana","description":"Вытягивает здоровье из существ рядом и даёт вам регенерацию","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:5}}

# Cleaving Cut
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Cleaving Cut","use_requirement":"Requires 60 mana","description":"Тяжело ранит всех рядом; накопление добавляет урона","id_number":3,"advancement_id":3,upgrades:[{},{}],unlock_cost:10}}

# Memento Mori
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Memento Mori","use_requirement":"Requires 100 mana","description":"Насылает наваждение на существо под курсором: оно прибавляет вам урона, но бить других вы больше не можете","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:20}}

# Unsealed Reaper
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Unsealed Reaper","use_requirement":"Requires 250 mana","description":"Вводит в состояние силы: вы быстрее, крепче, а способности мощнее","id_number":5,"advancement_id":5,upgrades:[{},{}],unlock_cost:80}}

# Death Compass
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Death Compass","use_requirement":"Requires 0 mana","description":"Создаёт стрелку, ведущую к ближайшему существу","id_number":6,"advancement_id":6,upgrades:[{},{}],unlock_cost:25}}
