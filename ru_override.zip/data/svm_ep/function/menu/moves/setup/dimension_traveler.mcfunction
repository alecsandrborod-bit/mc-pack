data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/dimension_traveler'
data modify storage svm_ep:menu power.temp.description set value "Very handy for those who just want to explore, free travel!"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Dimension Selection","use_requirement":"Requires 0 mana","description":"Выбирает измерение","id_number":3,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Portal","use_requirement":"Requires 20 mana","description":"Открывает впереди портал, переносящий существ и удары","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Dimensional Gate","use_requirement":"Requires 50 mana","description":"Открывает портал в другое измерение","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:20}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Front-Gates","use_requirement":"Requires 30 mana","description":"Открывает портал, переносящий существ к другому порталу","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Dimension Hop","use_requirement":"Requires 100 mana","description":"После накопления переносит вас и существ рядом в карманное измерение; возвращение маны не требует","id_number":5,"advancement_id":5,upgrades:[{},{}],unlock_cost:15}}
