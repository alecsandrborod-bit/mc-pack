data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/dimension_traveler'
data modify storage svm_ep:menu power.temp.description set value "Very handy for those who just want to explore, free travel!"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Выбор измерения","use_requirement":"Нужно 0 маны","description":"Выбирает измерение","id_number":3,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Портал","use_requirement":"Нужно 20 маны","description":"Открывает впереди портал, переносящий существ и удары","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Врата измерений","use_requirement":"Нужно 50 маны","description":"Открывает портал в другое измерение","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:20}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Передние врата","use_requirement":"Нужно 30 маны","description":"Открывает портал, переносящий существ к другому порталу","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Прыжок между мирами","use_requirement":"Нужно 100 маны","description":"После накопления переносит вас и существ рядом в карманное измерение; возвращение маны не требует","id_number":5,"advancement_id":5,upgrades:[{},{}],unlock_cost:15}}
