data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/explosion'
data modify storage svm_ep:menu power.temp.description set value "Made for destruction, may god forbid the spam technique 🙏"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Explosion","use_requirement":"Requires 10 mana, charging drains","description":"Вызывает взрыв впереди","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Explosive Bullet","use_requirement":"Requires 10 mana, charging drains","description":"Выпускает накапливаемый снаряд, взрывающийся при попадании","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Explosive Dash","use_requirement":"Requires 5 mana, charging drains","description":"Бросает вас вперёд","id_number":5,"advancement_id":3,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Smoke Barrier","use_requirement":"Requires 1 mana, holding drains","description":"Пускает дым, замедляя и ослепляя существ","id_number":3,"advancement_id":5,upgrades:[{},{}],unlock_cost:5}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Explosive Train","use_requirement":"Requires 15 mana, drains","description":"Взрывает у вас за спиной и бросает вперёд; дальность зависит от уровня, а кончится мана — полёт оборвётся","id_number":6,"advancement_id":6,upgrades:[{},{}],unlock_cost:40}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Re-Explode","use_requirement":"Requires 50 mana, drains","description":"Отдаёт уйму здоровья ради огромного взрыва","id_number":7,"advancement_id":7,"unlock_requirement":"Unlock from Paradise Traders",upgrades:[{},{}],unlock_cost:9999}}



#tellraw @s [{"text":"| ","color":"gray"},{"text":"Взрывной запуск ","color":"yellow","hover_event":{"action":"show_text","value":"Бросает вас вперёд; чем дольше держите Shift, тем дальше и быстрее"}},{"text":"- Нужно 15 маны","color":"gray"},{"text":" [Привязать]","color":"#F4D5FF","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 4"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы привязать к выбранному слоту"}},{"text":" [Открыть]","color":"#8fffef","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 20018"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы открыть за 10 очков способностей"}}]
#tellraw @s [{"text":"|","color":"gray"}]

#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Разрушитель земли","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"Ставит метку под курсором; через 6 секунд она взрывается","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужны Жезл взрыва и 10 маны","color":"gold"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Взрывной заряд","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"С каждым применением после установки метки Разрушитель земли растёт","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужны Жезл взрыва и 2 маны","color":"gold"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Отменить взрыв","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"Останавливает Разрушителя земли","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужен Жезл взрыва во второй руке","color":"gold"}]
