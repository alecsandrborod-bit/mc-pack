data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/harpie'
data modify storage svm_ep:menu power.temp.description set value "И орёл поначалу беспомощен"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Крылья","use_requirement":"Замедляет восстановление маны","description":"Надевает или снимает крылья","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Бритвенное перо","use_requirement":"Нужно 5 маны","description":"Выпускает перо из ваших крыльев","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Сверхпрыжок","use_requirement":"Нужно 25 маны","description":"Мощно подбрасывает вас вверх","id_number":3,"advancement_id":3,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Перьевой подъём","use_requirement":"Нужно 60 маны","description":"Подбрасывает всех рядом вверх","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Захват","use_requirement":"Нужно 60 маны, тратит","description":"Хватает существо впереди на несколько секунд","id_number":5,"advancement_id":5,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Управление перьями","use_requirement":"Нужно 5 маны, тратит","description":"Отправляет уже выпущенное Бритвенное перо к курсору","id_number":6,"advancement_id":6,upgrades:[{},{}],unlock_cost:15}}



#OLD tellraw @s [{"text":"| ","color":"gray"},{"text":"Захват ","color":"yellow","hover_event":{"action":"show_text","value":"Хватает существо впереди на несколько секунд"}},{"text":"- Нужно 60 маны","color":"gray"},{"text":" [Привязать]","color":"#F4D5FF","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 5"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы привязать к выбранному слоту"}},{"text":" [Открыть]","color":"#8fffef","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set 20056"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы открыть за 10 очков способностей"}}]
#NEW function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Захват","use_requirement":"Нужно 60 маны, тратит","description":"Хватает существо впереди на несколько секунд","id_number":5,"unlock_id":"20056","unlock_requirement":"Click to unlock for 10 Ability Points"}
