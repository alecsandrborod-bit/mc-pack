data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/slime'
data modify storage svm_ep:menu power.temp.description set value "Who would've thought you can teleport with slime?"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Slime Spit","use_requirement":"Requires 10 mana","description":"Плюётся слизью","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Slimy Rain","use_requirement":"Requires 20 mana","description":"Раскидывает вокруг комки слизи","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Slimy Shift","use_requirement":"Requires 25 mana","description":"Переносит вас к блоку слизи под курсором","id_number":4,"advancement_id":3,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Explosive Slime","use_requirement":"Requires 20 mana","description":"Подрывает блоки слизи под курсором","id_number":5,"advancement_id":4,upgrades:[{},{}],unlock_cost:5}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Slime Barrier","use_requirement":"Requires 25 mana","description":"Ставит впереди стену из слизи","id_number":6,"advancement_id":5,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Slimy Legs","use_requirement":"Requires 10 mana","description":"Вы быстрее плаваете и выше прыгаете","id_number":3,"advancement_id":6,upgrades:[{},{}],unlock_cost:5}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Slime Extension","use_requirement":"Requires 1 mana, holdable","description":"Ставит блок под курсором, если рядом с ним есть блок слизи","id_number":7,"advancement_id":7,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Living Slime","use_requirement":"Requires 25 mana","description":"Делает слизня из блока слизи под курсором; через время он растает","id_number":8,"advancement_id":8,upgrades:[{},{}],unlock_cost:30}}
