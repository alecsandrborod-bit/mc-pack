data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/lightning'
data modify storage svm_ep:menu power.temp.description set value "Прямо из взбудораженной энергии!"



function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Молния","use_requirement":"Нужно 30 маны","description":"Бьёт молнией под курсором","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Электрическая нить","use_requirement":"Нужно 20 маны, накопление тратит","description":"Выпускает вперёд накапливаемую электрическую нить","id_number":7,"advancement_id":2,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Накопление","use_requirement":"Нужно 25 маны, накопление тратит","description":"Напитывает вас электричеством и даёт большое преимущество","id_number":16,"advancement_id":6,upgrades:[{},{}],unlock_cost:20}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Электрическая зона","use_requirement":"Нужно 10 маны, удержание тратит","description":"Ранит и замедляет существ и снаряды вокруг","id_number":17,"advancement_id":7,upgrades:[{},{}],unlock_cost:10}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Метка молнии","use_requirement":"Нужно 10 маны","description":"Ставит под курсором метку для молнии","id_number":5,"advancement_id":3,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Призыв молний","use_requirement":"Сбрасывает способность Метка молнии","description":"Бьёт молниями по меткам, поставленным способностью Метка молнии","id_number":6,"advancement_id":3,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Разряд","use_requirement":"Нужно 325 маны","description":"Бьёт мощным залпом, круша всё живое и неживое впереди","id_number":13,"advancement_id":4,upgrades:[{},{}],unlock_cost:70}}

#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Громовая поступь","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"С каждым применением ускоряет","color":"gold"},{"text":" - ","color":"gray"},{"text":"Открывается на 10-м уровне, нужно 5 маны","color":"gold"}]
#tellraw @s [{"text":"|","color":"gray"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Громовой разрез","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"Рывок вперёд с уроном","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужны катана и 10 маны","color":"gold"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Шесть разрезов","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"Повторяет [Громовой разрез] шесть раз","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужны катана и 25 маны","color":"gold"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Громовой танец","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"Ускоряет, пока вы наносите урон; прыжки продлевают действие","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужны катана и 30 маны","color":"gold"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Вспышка света","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"Стремительный рывок вперёд с огромным уроном","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужны катана и 250 маны","color":"gold"}]




function svm_ep:menu/moves/add_ability/custom_multi_dialog {size:175,data:{type:"minecraft:multi_action",can_close_with_escape:1,actions:[{action:{type:"minecraft:run_command",command:"trigger svm_ep.menu set 4"},label:{color:"#db0000",text:"Меню сил"}}],pause:0,title:{color:"#a8fff5",text:" Постоянные способности"},body:[{type:"minecraft:item",description:[{color:"#fef69a",text:"Сила Грозы"},{color:"#9c9c9c",text:" - "},{color:"#d4d4d4",text:"В грозу перезарядки короче, а мана копится быстрее"}],show_tooltip:0,show_decorations:0,item:{id:"minecraft:blaze_powder"}},{type:"minecraft:item",description:[{color:"#fef69a",text:"Под водой"},{color:"#9c9c9c",text:" - "},{color:"#d4d4d4",text:"В воде тратит ману"}],show_tooltip:0,show_decorations:0,item:{id:"minecraft:water_bucket"}}],after_action:"none"}}