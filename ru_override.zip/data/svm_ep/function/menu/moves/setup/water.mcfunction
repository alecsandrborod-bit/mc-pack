data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/water'
data modify storage svm_ep:menu power.temp.description set value "Бесформенное — тоже форма?"

function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Создание воды","use_requirement":"Нужно 5 маны","description":"Наливает воду под курсором","id_number":1,"advancement_id":1,upgrades:[{},{}],unlock_cost:0}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Сбор воды","use_requirement":"Нужно 1 маны","description":"Собирает воду вокруг","id_number":2,"advancement_id":2,upgrades:[{},{}],unlock_cost:5}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Течение","use_requirement":"Нужно 0 маны","description":"Включает ускорение в воде (и позволяет в ней прыгать!)","id_number":3,"advancement_id":3,upgrades:[{},{}],unlock_cost:8}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Управление","use_requirement":"Нужно 1 маны","description":"Позволяет крутить водовороты, править водой и каплями и помогает в воде (удержание и короткое нажатие могут работать по-разному)","id_number":4,"advancement_id":4,upgrades:[{},{}],unlock_cost:15}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Капля воды","use_requirement":"Нужно 10 маны, удержание тратит","description":"Создаёт маленькую каплю воды","id_number":5,"advancement_id":5,upgrades:[{},{}],unlock_cost:5}}
function svm_ep:menu/moves/add_ability/main_new {data:{"name":"Прибывающая вода","use_requirement":"Нужно 20 маны","description":"Умножает воду вокруг","id_number":6,"advancement_id":6,upgrades:[{},{}],unlock_cost:75}}
