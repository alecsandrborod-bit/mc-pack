# ACTIONS
# #TITLE
# #total_level

# #NAME

$dialog show @s {"type":"minecraft:multi_action","after_action":"none","pause":false,"can_close_with_escape":true,"title":$(title),"body":[{"type":"minecraft:plain_message","contents":[{"text":"Уровень: ","color":"#d5e7e7"},{"text":"$(total_level)",color:"#e2adff",bold:true}]},{"type":"minecraft:plain_message","contents":{"text":"$(name)","color":"$(color)"}}],"can_close_with_escape":true,"exit_action":{"label":{"text":"Выход","color":"red"},"width":85,"action":{"type":"minecraft:run_command","command":"trigger svm_ep.menu set $(display_id)"}},"columns":1,"actions":$(actions)}