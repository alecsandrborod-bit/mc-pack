tellraw @s [{"text":"| ","color":"gray"}]
tellraw @s [{"text":"| ","color":"gray"},{"text":"4Fun","bold":true,"color":"white"}]
tellraw @s [{"text":"| ","color":"gray"}]
tellraw @s [{"text":"| ","color":"gray"},{"text":"Зловещее святилище ","color":"yellow","hover_event":{"action":"show_text","value":"Открывает вокруг вас зону разрезов"}},{"text":"- Нужно 100 маны, накопление тратит","color":"gray"},{"text":" [Привязать]","color":"#F4D5FF","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 1"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы привязать к выбранному слоту"}}]
tellraw @s [{"text":"| ","color":"gray"},{"text":"Метеоритный дождь ","color":"yellow","hover_event":{"action":"show_text","value":"Обрушивает метеоры с неба по всему миру"}},{"text":"- Нужно 250 маны, накопление тратит","color":"gray"},{"text":" [Привязать]","color":"#F4D5FF","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set 2"},"hover_event":{"action":"show_text","value":"Щёлкните, чтобы привязать к выбранному слоту"}}]



#tellraw @s [{"text":"|","color":"gray"}]

#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Разрушитель земли","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"Ставит метку под курсором; через 6 секунд она взрывается","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужны Жезл взрыва и 10 маны","color":"gold"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Взрывной заряд","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"С каждым применением после установки метки Разрушитель земли растёт","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужны Жезл взрыва и 2 маны","color":"gold"}]
#tellraw @s ["",{"text":"| [","color":"gray"},{"text":"Отменить взрыв","color":"aqua"},{"text":"] - ","color":"gray"},{"text":"Останавливает Разрушителя земли","color":"gold"},{"text":" - ","color":"gray"},{"text":"Нужен Жезл взрыва во второй руке","color":"gold"}]
