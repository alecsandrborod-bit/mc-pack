
#$say $(name) $(description) $(use_requirement) $(id_number) $(unlock_id) $(unlock_requirement)
data remove storage svm_ep:temporary temp
data modify storage svm_ep:temporary temp set value {"power":"custom","color":"yellow",unlock_cost:0,unlock_requirement:default,requirement_item:"",requirement_item_count:1,requirement_item_name:"",unlock_requirement_type:"",requirement_type:default,upgrades:[{},{}]}
data modify storage svm_ep:temporary temp.power set from storage svm_ep:temporary data.current_power



$data modify storage svm_ep:temporary temp merge value $(data)
data modify storage svm_ep:temporary temp merge value {variants:{label:"",width:1}}


data modify storage svm_ep:temporary temp.requirement_type set from storage svm_ep:temporary temp.unlock_cost.type
data modify storage svm_ep:temporary temp.requirement_item set from storage svm_ep:temporary temp.unlock_cost.item
data modify storage svm_ep:temporary temp.requirement_item_count set from storage svm_ep:temporary temp.unlock_cost.count
data modify storage svm_ep:temporary temp.requirement_item_name set from storage svm_ep:temporary temp.unlock_cost.name
data modify storage svm_ep:temporary temp.unlock_cost set from storage svm_ep:temporary temp.unlock_cost.count
data modify storage svm_ep:temporary temp.unlock_requirement_type set from storage svm_ep:temporary temp.unlock_requirement

execute store result score %result svm_ep.numbers run data get storage svm_ep:temporary temp.id_number
scoreboard players operation %ability_id svm_ep.numbers = %result svm_ep.numbers
execute store result storage svm_ep:temporary temp.display_id int 1 run scoreboard players add %result svm_ep.numbers 30000
execute store result storage svm_ep:temporary temp.unlock_id int 1 run scoreboard players add %result svm_ep.numbers 10000

#function svm_ep:menu/moves/add_ability/main with storage svm_ep:temporary temp


execute unless data storage svm_ep:temporary temp{upgrades:0} run function svm_ep:menu/moves/add_ability/upgrades {index:0}
execute unless data storage svm_ep:temporary temp{upgrades:0} run function svm_ep:menu/moves/add_ability/upgrades {index:1}
execute unless data storage svm_ep:temporary temp{upgrades:0} run function svm_ep:menu/moves/add_ability/upgrades {index:2}
execute unless data storage svm_ep:temporary temp{upgrades:0} run function svm_ep:menu/moves/add_ability/upgrades {index:3}
execute unless data storage svm_ep:temporary temp{upgrades:0} run function svm_ep:menu/moves/add_ability/upgrades {index:4}


function svm_ep:menu/moves/add_ability/main_new_add_to_storage with storage svm_ep:temporary temp






#$tellraw @s [{"text":"| ","color":"gray"},{"text":"$(name) ","color":"yellow","hover_event":{"action":"show_text","value":"$(description)"}},{"text":"- $(use_requirement)","color":"gray"},{"text":" [Привязать]","color":"#F4D5FF","click_event":{"action":"run_command","command":"/trigger svm_ep.z.bind_ability set $(id_number)"},"hover_event":{"action":"show_text","value":"Click to bind [$(name)] to selected slot"}},{"text":" [Открыть]","color":"#8fffef","click_event":{"action":"run_command","command":"/trigger svm_ep.menu set $(unlock_id)"},"hover_event":{"action":"show_text","value":"[$(name)] $(unlock_requirement)"}}]