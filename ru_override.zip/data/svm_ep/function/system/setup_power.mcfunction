#$data modify storage svm_ep:power id append value $(data)

$data modify storage svm_ep:temporary data.current_power set value $(power)

data remove storage svm_ep:ability power.temp
data remove storage svm_ep:menu power.temp
data modify storage svm_ep:menu power.temp set from storage svm_ep:power temp
data remove storage svm_ep:menu power.temp.obtain_function
data remove storage svm_ep:menu power.temp.obtainable
data modify storage svm_ep:menu power.temp.icon set value 'svm_ep:icon/base'
data modify storage svm_ep:menu power.temp.description set value "Описание"
data modify storage svm_ep:menu power.temp.ability_points set value "Null"

$data modify storage svm_ep:data temp.dialog set value "svm_ep:menu/power/$(power)/perks_and_levels"
data modify storage svm_ep:data temp.label set from storage svm_ep:menu other.power_perks_and_leveling
data modify storage svm_ep:data temp.size set value 120
execute store result score %RESULT svm_ep.numbers run function svm_ep:system/validate_dialog_macro with storage svm_ep:data temp
execute if score %RESULT svm_ep.numbers matches 1.. run function svm_ep:menu/moves/add_ability/dialog with storage svm_ep:data temp


$function svm_ep:menu/moves/setup/$(power)

$scoreboard objectives add svm_ep.p.$(power)_level dummy
$scoreboard objectives add svm_ep.p.$(power)_level.max dummy


#data modify storage svm_ep:menu power.temp.abilities append value {"label":"","width":1,"action":{"type": "minecraft:run_command","command":"trigger svm_ep.menu set 2"}}
#data modify storage svm_ep:menu power.temp.abilities append value {"label":"","width":1,"action":{"type": "minecraft:run_command","command":"trigger svm_ep.menu set 2"}}
#data modify storage svm_ep:menu power.temp.abilities append value {"label":{"text":"Главное меню","color":"#e00043"},"action":{"type": "minecraft:run_command","command":"trigger svm_ep.menu set 1"}}

$data modify storage svm_ep:menu power.$(power) set from storage svm_ep:menu power.temp
$data modify storage svm_ep:ability power.$(power) set from storage svm_ep:ability power.temp

scoreboard players set %get_power_into_roll svm_ep.numbers 0



$data modify storage svm_ep:menu chooser.powers append value {label:{text:"$(name)",color:"$(color)"},width:170,action:{type:"minecraft:run_command",command:"$(obtain_function)"}}

execute unless data storage svm_ep:power {temp:{obtainable:false}} run scoreboard players set %get_power_into_roll svm_ep.numbers 1
#execute if data storage svm_ep:power {temp:{obtainable:false}} run scoreboard players set %get_power_into_roll svm_ep.numbers 0
$execute if score $(power)Obtainable svm_ep.gamerule matches 1 run scoreboard players set %get_power_into_roll svm_ep.numbers 1
$execute if score $(power)Obtainable svm_ep.gamerule matches 0 run scoreboard players set %get_power_into_roll svm_ep.numbers 0



execute if score %get_power_into_roll svm_ep.numbers matches 1 run data modify storage svm_ep:power roll append from storage svm_ep:power temp.obtain_function


