tellraw @s [{"text":"| Нужна катана!","color":"gray"}]
