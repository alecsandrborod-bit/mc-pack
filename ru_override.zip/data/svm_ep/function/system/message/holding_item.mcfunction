tellraw @s [{"text":"| У вас в руке предмет!","color":"gray"}]
