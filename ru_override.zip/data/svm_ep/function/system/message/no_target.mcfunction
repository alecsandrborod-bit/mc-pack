tellraw @s [{"text":"| Целей не найдено!","color":"gray"}]
