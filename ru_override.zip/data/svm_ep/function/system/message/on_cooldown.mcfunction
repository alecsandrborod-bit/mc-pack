tellraw @s [{"text":"| Перезарядка!","color":"gray"}]
