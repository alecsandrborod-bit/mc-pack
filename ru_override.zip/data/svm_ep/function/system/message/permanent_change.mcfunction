tellraw @s [{"text":"| Это изменение необратимо!","color":"gray"}]
