tellraw @s [{"text":"| Не хватает маны!","color":"gray"}]
