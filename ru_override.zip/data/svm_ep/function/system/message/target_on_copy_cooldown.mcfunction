tellraw @s [{"text":"| С этой цели недавно уже копировали!","color":"gray"}]
