tellraw @s [{"text":"| Скопировать не вышло!","color":"gray"}]
