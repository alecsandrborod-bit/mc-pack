tellraw @s [{"text":"| Дальше улучшать некуда!","color":"gray"}]
