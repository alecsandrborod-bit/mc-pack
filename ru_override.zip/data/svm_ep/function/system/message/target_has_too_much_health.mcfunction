tellraw @s [{"text":"| У цели слишком много здоровья!","color":"gray"}]
