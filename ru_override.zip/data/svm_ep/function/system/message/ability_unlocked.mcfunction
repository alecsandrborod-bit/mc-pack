tellraw @s [{"text":"| Способность уже открыта!","color":"gray"}]
