tellraw @s [{"text":"| Применений не осталось!","color":"gray"}]
