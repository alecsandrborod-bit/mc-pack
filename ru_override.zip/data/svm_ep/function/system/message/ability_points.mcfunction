tellraw @s [{"text":"| Очки способностей: ","color":"gray"},{"score":{"name":"@s","objective":"svm_ep.ability_points"},"bold":true,"color":"white"}]
