tellraw @s [{"text":"| Осталось очков способностей: ","color":"gray"},{"score":{"name":"@s","objective":"svm_ep.ability_points"},"bold":true,"color":"white"}]
