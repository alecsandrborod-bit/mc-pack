tellraw @s [{"text":"| Вы применяете способность!","color":"gray"}]
