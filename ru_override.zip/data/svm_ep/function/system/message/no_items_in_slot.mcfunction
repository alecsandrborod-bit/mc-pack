tellraw @s [{"text":"| У вас в руке ничего нет!","color":"gray"}]
