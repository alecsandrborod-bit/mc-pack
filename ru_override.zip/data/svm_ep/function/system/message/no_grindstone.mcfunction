tellraw @s [{"text":"| Точила нет!","color":"gray"}]
