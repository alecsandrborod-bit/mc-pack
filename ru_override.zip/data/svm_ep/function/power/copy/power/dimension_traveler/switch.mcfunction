function svm_ep:power/dimension_traveler/selection/switch
playsound minecraft:block.respawn_anchor.set_spawn master @a[distance=..25] ~ ~ ~ 0.5 2
scoreboard players reset @s svm_ep.charge_length


tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=1}] [{"text":"| Destination: Верхний мир |","color":"gray"}]
tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=2}] [{"text":"| Destination: Нижний мир |","color":"gray"}]
tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=3}] [{"text":"| Destination: Край |","color":"gray"}]
tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=4}] [{"text":"| Destination: Рай |","color":"gray"}]
tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=5}] [{"text":"| Destination: Вишнёвый остров |","color":"gray"}]
