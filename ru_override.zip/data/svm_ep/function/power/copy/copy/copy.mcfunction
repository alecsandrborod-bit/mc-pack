
execute if score %COPIED_ABILITY svm_ep.numbers matches 2 run return run function svm_ep:power/copy/copy/copied {id:"02",name:"Броня броненосца"}
execute if score %COPIED_ABILITY svm_ep.numbers matches 3 run return run function svm_ep:power/copy/copy/copied {id:"03",name:"Приспособление к воде"}
execute if score %COPIED_ABILITY svm_ep.numbers matches 4 run return run function svm_ep:power/copy/copy/copied {id:"04",name:"Ночное зрение"}
execute if score %COPIED_ABILITY svm_ep.numbers matches 5 run return run function svm_ep:power/copy/copy/copied {id:"05",name:"Огненный шар"}
execute if score %COPIED_ABILITY svm_ep.numbers matches 6 run return run function svm_ep:power/copy/copy/copied {id:"06",name:"Огненная закалка"}
execute if score %COPIED_ABILITY svm_ep.numbers matches 7 run return run function svm_ep:power/copy/copy/copied {id:"07",name:"Заряд ветра"}
execute if score %COPIED_ABILITY svm_ep.numbers matches 8 run return run function svm_ep:power/copy/copy/copied {id:"08",name:"Ядовитый укус"}
execute if score %COPIED_ABILITY svm_ep.numbers matches 9 run return run function svm_ep:power/copy/copy/copied {id:"09",name:"Сердце скрипуна"}

execute store result storage svm_ep:numbers input.id int 1 run scoreboard players get %COPIED_ABILITY svm_ep.numbers
execute if score %COPIED_ABILITY svm_ep.numbers matches 10 run data modify storage svm_ep:numbers input.name set value "Самоуничтожение"
execute if score %COPIED_ABILITY svm_ep.numbers matches 11 run data modify storage svm_ep:numbers input.name set value "Взгляд стража"
execute if score %COPIED_ABILITY svm_ep.numbers matches 12 run data modify storage svm_ep:numbers input.name set value "Дыхание дракона"
execute if score %COPIED_ABILITY svm_ep.numbers matches 13 run data modify storage svm_ep:numbers input.name set value "Телепортация"
execute if score %COPIED_ABILITY svm_ep.numbers matches 14 run data modify storage svm_ep:numbers input.name set value "Клыки особняка"
execute if score %COPIED_ABILITY svm_ep.numbers matches 15 run data modify storage svm_ep:numbers input.name set value "Невидимость"
execute if score %COPIED_ABILITY svm_ep.numbers matches 16 run data modify storage svm_ep:numbers input.name set value "Грибная подпитка"
execute if score %COPIED_ABILITY svm_ep.numbers matches 17 run data modify storage svm_ep:numbers input.name set value "Снаряд шалкера"
execute if score %COPIED_ABILITY svm_ep.numbers matches 18 run data modify storage svm_ep:numbers input.name set value "Выстрел паутиной"
execute if score %COPIED_ABILITY svm_ep.numbers matches 19 run data modify storage svm_ep:numbers input.name set value "Звуковой удар"
execute if score %COPIED_ABILITY svm_ep.numbers matches 20 run data modify storage svm_ep:numbers input.name set value "Иссушающее касание"
execute if score %COPIED_ABILITY svm_ep.numbers matches 21 run data modify storage svm_ep:numbers input.name set value "Голова визера"

execute if score %COPIED_ABILITY svm_ep.numbers matches 22 run data modify storage svm_ep:numbers input.name set value "Сила Фазы"
execute if score %COPIED_ABILITY svm_ep.numbers matches 23 run data modify storage svm_ep:numbers input.name set value "Сила Молнии"
execute if score %COPIED_ABILITY svm_ep.numbers matches 24 run data modify storage svm_ep:numbers input.name set value "Сила Флоры"
execute if score %COPIED_ABILITY svm_ep.numbers matches 25 run data modify storage svm_ep:numbers input.name set value "Сила Слизи"
execute if score %COPIED_ABILITY svm_ep.numbers matches 26 run data modify storage svm_ep:numbers input.name set value "Сила Взрыва"
execute if score %COPIED_ABILITY svm_ep.numbers matches 27 run data modify storage svm_ep:numbers input.name set value "Сила Льда"
execute if score %COPIED_ABILITY svm_ep.numbers matches 28 run data modify storage svm_ep:numbers input.name set value "Сила Гравитации"
execute if score %COPIED_ABILITY svm_ep.numbers matches 29 run data modify storage svm_ep:numbers input.name set value "Сила Гарпии"
execute if score %COPIED_ABILITY svm_ep.numbers matches 30 run data modify storage svm_ep:numbers input.name set value "Сила Странника измерений"
execute if score %COPIED_ABILITY svm_ep.numbers matches 31 run data modify storage svm_ep:numbers input.name set value "Сила Огня"
execute if score %COPIED_ABILITY svm_ep.numbers matches 32 run data modify storage svm_ep:numbers input.name set value "Сила Бездны"
execute if score %COPIED_ABILITY svm_ep.numbers matches 33 run data modify storage svm_ep:numbers input.name set value "Сила Времени"
execute if score %COPIED_ABILITY svm_ep.numbers matches 34 run data modify storage svm_ep:numbers input.name set value "Сила Исцеления"
execute if score %COPIED_ABILITY svm_ep.numbers matches 35 run data modify storage svm_ep:numbers input.name set value "Сила Смерти"

function svm_ep:power/copy/copy/copied with storage svm_ep:numbers input