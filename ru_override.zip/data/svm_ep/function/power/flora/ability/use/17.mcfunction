

execute as @s[scores={svm_ep.using_move=1..}] run return run function svm_ep:system/message/using_move
execute as @s[type=player,advancements={svm_ep:flora_visited_biome/forest=false}] run return 0


scoreboard players set %COST svm_ep.numbers 40


function svm_ep:system/math/modify_cost
execute if score @s svm_ep.mana < %COST svm_ep.numbers run return run function svm_ep:system/message/not_enough_mana

scoreboard players operation %cooldown1 svm_ep.numbers = @s svm_ep.p.flora_ability_17_delay
function svm_ep:system/cooldown/calculate
execute if score %cooldown1 svm_ep.numbers matches 1.. run return run function svm_ep:system/message/on_cooldown


scoreboard players set $COOLDOWN_NEW svm_ep.numbers 10
function svm_ep:system/math/modify_cooldown
scoreboard players operation @s svm_ep.p.flora_ability_17_delay = $COOLDOWN_NEW svm_ep.numbers










tag @s add executor
execute anchored eyes positioned ^ ^ ^1 run function svm_ep:power/flora/root_entangle/raycast
tag @s remove executor
tellraw @s[scores={svm_ep.numbers=1}] ["",{"text":"Нужен деревянный блок под курсором","color":"red"},{"text":"!","color":"dark_gray"}]
tellraw @s[scores={svm_ep.numbers=2}] [{"text":"Здесь нельзя: способность недавно уже применяли","color":"red"},{"text":"!","color":"dark_gray"}]

scoreboard players add @s[scores={svm_ep.numbers=3}] svm_ep.p.flora_ability_17_delay 130
scoreboard players operation @s svm_ep.mana -= %COST svm_ep.numbers
effect give @s[scores={svm_ep.numbers=3}] minecraft:slowness 1 3 true
scoreboard players reset @s svm_ep.numbers