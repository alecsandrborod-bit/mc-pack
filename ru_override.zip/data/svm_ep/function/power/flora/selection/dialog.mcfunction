$dialog show @s {type:"minecraft:multi_action",title:[{"text":"Выбор климата","color":"#08ff50"}],body:{type:"minecraft:item",item:{id:"minecraft:oak_sapling"},description:{text:"Click on the climate to select it and use its ability variants!"},show_decorations:0b,show_tooltip:0b},can_close_with_escape:1b,pause:1b,after_action:"close",columns:3,actions:$(climates),"can_close_with_escape":1,"pause":0}


