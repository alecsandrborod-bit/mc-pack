$dialog show @s {type:"minecraft:multi_action",title:[{"text":"Способность климата","color":"#15ff07"}],body:{type:"minecraft:item",item:{id:"minecraft:oak_sapling"},description:{text:"Click on the ability to instantly use it!"},show_decorations:0b,show_tooltip:0b},can_close_with_escape:1b,pause:1b,after_action:"close",columns:3,actions:$(climate_abilities),"can_close_with_escape":1,"pause":0}

