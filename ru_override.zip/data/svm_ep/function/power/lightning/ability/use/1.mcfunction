execute as @s[scores={svm_ep.using_move=1..}] run return run function svm_ep:system/message/using_move

#COST
scoreboard players set %COST svm_ep.numbers 30


function svm_ep:system/math/modify_cost
execute if score @s svm_ep.mana < %COST svm_ep.numbers run return run function svm_ep:system/message/not_enough_mana


execute as @s[scores={svm_ep.p.lightning_ability_01_delay=1..}] run return run function svm_ep:system/message/on_cooldown


#CD
scoreboard players set $COOLDOWN_NEW svm_ep.numbers 300
execute as @s[tag=svm_ep.npc_thunder_god] run scoreboard players set $COOLDOWN_NEW svm_ep.numbers 100
execute if predicate svm_ep:thunder run scoreboard players operation $COOLDOWN_NEW svm_ep.numbers *= %thunder_passive_cooldown_multiplier svm_ep.world_settings
execute if predicate svm_ep:thunder run scoreboard players operation $COOLDOWN_NEW svm_ep.numbers /= %thunder_passive_cooldown_divisor svm_ep.world_settings
function svm_ep:system/math/modify_cooldown_old
scoreboard players operation @s svm_ep.p.lightning_ability_01_delay = $COOLDOWN_NEW svm_ep.numbers

scoreboard players operation @s svm_ep.mana -= %COST svm_ep.numbers









scoreboard players add @s svm_ep.used_move 160
execute at @s run scoreboard players set @a[distance=..30] svm_ep.clear_slowness 5
execute at @s run effect give @a[distance=..30] minecraft:slowness 1 6 true
execute at @s run scoreboard players set @a[distance=..30] svm_ep.clear_speed 8
execute at @s run effect give @a[distance=..30] minecraft:speed 1 5 true

function svm_ep:power/lightning/lightning/start_raycast


execute store result score @s[tag=svm_ep.npc] svm_ep.numbers run random value 1..3
execute if predicate svm_ep:chance/67_percent run scoreboard players reset @s svm_ep.numbers
execute at @s[tag=svm_ep.npc_thunder_god,scores={svm_ep.numbers=1}] run tellraw @a[distance=..50] ["",{"text":"[","color":"gray"},{"selector":"@s","bold":true},{"text":"] ","color":"gray"},{"text":"В чём дело?","color":"#91FFFF"}]
execute at @s[tag=svm_ep.npc_thunder_god,scores={svm_ep.numbers=2}] run tellraw @a[distance=..50] ["",{"text":"[","color":"gray"},{"selector":"@s","bold":true},{"text":"] ","color":"gray"},{"text":"Думаешь, уйдёшь?","color":"#91FFFF"}]
execute at @s[tag=svm_ep.npc_thunder_god,scores={svm_ep.numbers=3}] run tellraw @a[distance=..50] ["",{"text":"[","color":"gray"},{"selector":"@s","bold":true},{"text":"] ","color":"gray"},{"text":"Расстояние не помеха!","color":"#91FFFF"}]
execute at @s[tag=svm_ep.npc_thunder_god,scores={svm_ep.numbers=1..}] run playsound minecraft:entity.evoker.ambient hostile @a[distance=..50] ~ ~1 ~ 4 0.7