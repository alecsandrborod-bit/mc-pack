tellraw @s ["",{"text":"| Достигнут предельный размер! (to improve, get more Уровень опытаs)","color":"gray"}]

function svm_ep:power/ice/berg/end_charge
