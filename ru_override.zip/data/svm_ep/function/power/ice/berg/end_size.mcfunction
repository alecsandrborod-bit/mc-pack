tellraw @s ["",{"text":"| Достигнут предельный размер! ","color":"gray"}]

function svm_ep:power/ice/berg/end_charge
