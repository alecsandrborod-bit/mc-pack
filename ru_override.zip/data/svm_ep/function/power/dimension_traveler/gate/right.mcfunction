execute at @s run playsound minecraft:block.stone_button.click_off master @a[tag=same_id] ~ ~ ~ 1 2

#1 OVERWORLD
#2 NETHER
#3 END
#4 PARADISE
#5 CHERRY ISLAND

function svm_ep:power/dimension_traveler/gate/switch



execute if dimension minecraft:overworld run scoreboard players add @s[scores={svm_ep.p.dimension_traveler_gate_destination=1}] svm_ep.p.dimension_traveler_gate_destination 1
tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=1}] [{"text":"| Destination: Верхний мир","color":"gray"}]
tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=2}] [{"text":"| Destination: Нижний мир","color":"gray"}]
tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=3}] [{"text":"| Destination: Край","color":"gray"}]
tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=4}] [{"text":"| Destination: Рай","color":"gray"}]
tellraw @s[scores={svm_ep.p.dimension_traveler_gate_destination=5}] [{"text":"| Destination: Вишнёвый остров","color":"gray"}]
