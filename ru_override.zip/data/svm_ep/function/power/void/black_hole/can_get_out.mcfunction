title @s times 3t 5t 3t
title @s subtitle [{"text":"|","color":"gray"},{"text":" Hold ","color":"#C5B9CB"},{"text":"space/jump","bold":true,"color":"#EFB7FF"},{"text":" чтобы выйти ","color":"#C5B9CB"},{"text":"|","color":"gray"}]

execute as @s[scores={input.jump_time=32..}] run function svm_ep:power/void/black_hole/tp_out
execute as @s[scores={input.jump_time=24..}] run return run title @s title [{"text":"> ","color":"white"},{"text":"\u2588\u2588\u2588","color":"light_purple"},{"text":" <","color":"white"}]
execute as @s[scores={input.jump_time=16..}] run return run title @s title [{"text":"> ","color":"white"},{"text":"\u2588\u2588","color":"light_purple"},{"text":"\u2588","color":"#AB9AAB"},{"text":" <","color":"white"}]
execute as @s[scores={input.jump_time=8..}] run return run title @s title [{"text":"> ","color":"white"},{"text":"\u2588","color":"light_purple"},{"text":"\u2588\u2588","color":"#AB9AAB"},{"text":" <","color":"white"}]
title @s title ""
