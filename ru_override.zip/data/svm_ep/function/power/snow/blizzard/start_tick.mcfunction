execute unless predicate svm_ep:holding_ability run return run function svm_ep:power/snow/blizzard/toggle
scoreboard players add @s svm_ep.using_move 1
scoreboard players add @s svm_ep.used_move 4
scoreboard players add @s svm_ep.p.snow_ability_05_delay 1
scoreboard players add @s svm_ep.p.snow_blizzard.size_score 1

execute unless score @s svm_ep.p.snow_blizzard.size_score >= %snow_blizzard_divisor svm_ep.world_settings run return 0

scoreboard players add @s svm_ep.p.snow_blizzard.size 1
scoreboard players operation @s svm_ep.p.snow_blizzard.size < %snow_blizzard_max_size svm_ep.world_settings


scoreboard players reset @s svm_ep.p.snow_blizzard.size_score
title @s subtitle [{"text":"Размер бурана: ","color":"gray"},{"score":{"name":"@s","objective":"svm_ep.p.snow_blizzard.size"},"bold":true,"color":"aqua"},{"text":"/","color":"gray"},{"score":{"name":"%snow_blizzard_max_size","objective":"svm_ep.world_settings"},"bold":true,"color":"aqua"}]
title @s title ""


execute at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.5 0.9