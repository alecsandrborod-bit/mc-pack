execute as @s[scores={svm_ep.charge_length3=20..}] unless entity @s[scores={svm_ep.p.level=25..}] run return 0
execute as @s[scores={svm_ep.charge_length3=40..}] unless entity @s[scores={svm_ep.p.level=50..}] run return 0
execute as @s[scores={svm_ep.charge_length3=60..}] unless entity @s[scores={svm_ep.p.level=75..}] run return 0
execute as @s[scores={svm_ep.charge_length3=80..}] unless entity @s[scores={svm_ep.p.level=125..}] run return 0
execute as @s[scores={svm_ep.charge_length3=100..}] run return 0


scoreboard players add @s svm_ep.charge_length3 1
scoreboard players operation @s svm_ep.numbers = @s svm_ep.charge_length3
scoreboard players operation @s svm_ep.numbers %= %20 svm_ep.numbers

execute unless entity @s[scores={svm_ep.numbers=0}] run return 0

title @s[scores={svm_ep.charge_length3=20}] subtitle [{text:"Размер расчистки: ",color:gray},{text:"1",color:aqua}]
title @s[scores={svm_ep.charge_length3=40}] subtitle [{text:"Размер расчистки: ",color:gray},{text:"2",color:aqua}]
title @s[scores={svm_ep.charge_length3=60}] subtitle [{text:"Размер расчистки: ",color:gray},{text:"3",color:aqua}]
title @s[scores={svm_ep.charge_length3=80}] subtitle [{text:"Размер расчистки: ",color:gray},{text:"4",color:aqua}]
title @s[scores={svm_ep.charge_length3=100}] subtitle [{text:"Размер расчистки: ",color:gray},{text:"5",color:aqua}]
title @s title ""


execute at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.5 1.1