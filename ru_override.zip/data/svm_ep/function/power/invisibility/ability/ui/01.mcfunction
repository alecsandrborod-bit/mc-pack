scoreboard players operation %cooldown1 svm_ep.numbers = @s svm_ep.p.invisibility_ability_01_delay
function svm_ep:system/cooldown/calculate

$execute as @s[scores={svm_ep.p.invisibility_toggle.active=1..}] unless score %cooldown1 svm_ep.numbers matches 1.. run return run title @s actionbar [$(mana_display),{"text":" I","color":"#8ab7a9"},{"text":"n","color":"#9cc2b6"},{"text":"v","color":"#afcdc4"},{"text":"i","color":"#c2d8d1"},{"text":"s","color":"#d4e3df"},{"text":"i","color":"#e7eeec"},{"text":"b","color":"#fafafa"},{"text":"i","color":"#e3ece9"},{"text":"l","color":"#cddfd9"},{"text":"i","color":"#b6d1c9"},{"text":"t","color":"#a0c4b9"},{"text":"y","color":"#8ab7a9"},{"text":" |","color":"gray"},{"text":" Активно","color":"#abf2b7"}]
$execute unless score %cooldown1 svm_ep.numbers matches 1.. run return run title @s actionbar [$(mana_display),{"text":" I","color":"#8ab7a9"},{"text":"n","color":"#9cc2b6"},{"text":"v","color":"#afcdc4"},{"text":"i","color":"#c2d8d1"},{"text":"s","color":"#d4e3df"},{"text":"i","color":"#e7eeec"},{"text":"b","color":"#fafafa"},{"text":"i","color":"#e3ece9"},{"text":"l","color":"#cddfd9"},{"text":"i","color":"#b6d1c9"},{"text":"t","color":"#a0c4b9"},{"text":"y","color":"#8ab7a9"},{"text":" |","color":"gray"}]

function svm_ep:power/delay
$title @s actionbar [$(mana_display),{"text":" I","strikethrough":true,"color":"#4d4d4d"},{"text":"n","strikethrough":true,"color":"#5a5a5a"},{"text":"v","strikethrough":true,"color":"#676767"},{"text":"i","strikethrough":true,"color":"#747474"},{"text":"s","strikethrough":true,"color":"#818181"},{"text":"i","strikethrough":true,"color":"#8e8e8e"},{"text":"b","strikethrough":true,"color":"#9c9c9c"},{"text":"i","strikethrough":true,"color":"#8c8c8c"},{"text":"l","strikethrough":true,"color":"#7c7c7c"},{"text":"i","strikethrough":true,"color":"#6c6c6c"},{"text":"t","strikethrough":true,"color":"#5c5c5c"},{"text":"y ","strikethrough":true,"color":"#4d4d4d"},{"text":"|","color":"gray"},$(cooldown_display)]



