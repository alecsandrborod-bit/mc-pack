execute as @s[type=player] run return run tellraw @s "Нельзя выполнить от лица игрока"
data merge entity @s {Profession:0,Offers:{Recipes:[]},Tags:["svm_ep.npc","svm_ep.npc.calcite_gatherer"],CustomName:"Calcite Gatherer",CanPickUpLoot:0b,OnGround:1b,PersistenceRequired:1b,HandDropChances:[0.00f],Glowing:1b}



item replace entity @s armor.head with blue_dye[item_model="svm_ep:npc/paradise_trader/head"]

attribute @s minecraft:max_health base set 50
attribute @s minecraft:step_height base set 2
data merge entity @s {Health:50}


function svm_ep:npc/calcite_gatherer/trades
function svm_ep:system/message/spawned_at {"selector":"@a[distance=..200]"}
playsound minecraft:item.goat_horn.sound.1 master @a[distance=..250] ~ ~1 ~ 1.7 0.5 0.9
particle minecraft:cloud ~ ~1 ~ 0 0 0 0.5 60

scoreboard players set %SUCCESS svm_ep.numbers 0
execute as @a[distance=..150,sort=nearest] unless score %SUCCESS svm_ep.numbers matches 1 run function svm_ep:npc/calcite_gatherer/attempt_target