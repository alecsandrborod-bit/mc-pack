execute as @s[type=player] run return run tellraw @s "Нельзя выполнить от лица игрока"
data merge entity @s {Tags:["svm_ep.npc","svm_ep.npc.calcite_hunter"],CustomName:"Calcite Hunter",CanPickUpLoot:0b,OnGround:1b,PersistenceRequired:1b}



item replace entity @s armor.head with amethyst_block
item replace entity @s armor.chest with minecraft:iron_chestplate[minecraft:trim={pattern:"minecraft:silence",material:amethyst}]
item replace entity @s armor.legs with minecraft:iron_leggings[minecraft:trim={pattern:"minecraft:silence",material:amethyst}]
item replace entity @s armor.feet with minecraft:iron_boots[minecraft:trim={pattern:"minecraft:flow",material:amethyst}]

execute if predicate svm_ep:chance/50_percent run item replace entity @s weapon.mainhand with iron_sword

attribute @s minecraft:max_health base set 70
data merge entity @s {Health:70}
attribute @s minecraft:step_height base set 3
attribute @s minecraft:follow_range base set 75
attribute @s minecraft:movement_speed modifier add svm_ep.npc.calcite_hunter 0.3 add_multiplied_total
attribute @s minecraft:attack_damage modifier add svm_ep.npc.calcite_hunter 0.3 add_multiplied_total
effect give @s minecraft:slow_falling infinite 0 true