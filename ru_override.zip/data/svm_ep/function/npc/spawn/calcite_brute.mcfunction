execute as @s[type=player] run return run tellraw @s "Нельзя выполнить от лица игрока"
function svm_ep:npc/calcite_brute/setup