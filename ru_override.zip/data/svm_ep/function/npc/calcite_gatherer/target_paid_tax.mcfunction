clear @s *[minecraft:custom_data~{svm_ep.item:{id:paid_calcite_tax}}] 1

scoreboard players reset @s svm_ep.npc.calcite_gatherer.targeted
scoreboard players reset @s svm_ep.npc.calcite_gatherer.targeted_last

scoreboard players operation @s svm_ep.npc.calcite_gatherer.targeted_cooldown = %WORLD ci.tick
scoreboard players add @s svm_ep.npc.calcite_gatherer.targeted_cooldown 15000

title @s times 5t 40t 5t
title @s subtitle {"text":"Кальцитовый налог уплачен",color:red}
title @s title "🎉 🥳 🎉"

execute at @s run particle minecraft:end_rod ~ ~1 ~ 0 0 0 0.4 10
execute at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~1 ~ 1 1.2 0.5