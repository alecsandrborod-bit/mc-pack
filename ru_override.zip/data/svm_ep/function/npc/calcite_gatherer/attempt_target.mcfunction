execute as @s[scores={svm_ep.npc.calcite_gatherer.targeted=1}] run return 0
execute if score @s svm_ep.npc.calcite_gatherer.targeted_cooldown > %WORLD ci.tick run return 0

scoreboard players set %SUCCESS svm_ep.numbers 1



scoreboard players operation @s svm_ep.npc.calcite_gatherer.targeted_last = %WORLD ci.tick
scoreboard players set @s svm_ep.npc.calcite_gatherer.targeted 1




title @s times 5t 40t 5t
title @s subtitle {"text":"Пора платить налоги!",color:red}
title @s title ""
