advancement revoke @s only svm_ep:data/killed_entity

execute unless score %running_svm_tick svm_ep.function matches 1 run return 0

#tellraw @s "Вы убили существо с силами!"

scoreboard players operation %exp svm_ep.numbers = @s svm_ep.p.level
scoreboard players add %exp svm_ep.numbers 5
scoreboard players operation %exp svm_ep.numbers /= %5 svm_ep.numbers
execute if score %exp svm_ep.numbers matches 10.. run scoreboard players set %exp svm_ep.numbers 210

scoreboard players operation @s svm_ep.p.level.score += %exp svm_ep.numbers
