$data modify storage ancient_artifacts:manual player_data.unlocked.artifact."$(dim)" append value {id:"$(id)"}
playsound minecraft:entity.player.levelup master @s ~ ~ ~
playsound minecraft:ui.toast.out master @s ~ ~ ~
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~
$execute store result score @s artifacts.$(dim) if data storage ancient_artifacts:manual player_data.unlocked.artifact."$(dim)"[]
data remove storage ancient_artifacts:manual names
$data modify storage ancient_artifacts:manual names append from entity @s Inventory[{"components":{"minecraft:custom_data":{"artifact":true,"data":{"id":"$(id)","rarity":$(rarity)b}}}}].components."minecraft:custom_name"
data modify storage ancient_artifacts:manual currArtifact.name set from storage ancient_artifacts:manual names[0]
tag @s add unlocker
tellraw @s [{text: "Вы нашли: ", color: "green"}, {nbt: "currArtifact.name", storage: "ancient_artifacts:manual", interpret: true}, {text: "! Загляните в справочник,", color: "green"}, {text: "\ufe5b\ufe56\ufe5c", color: "red", bold: true, hover_event: {action: "show_text", value: {text: "Справочник артефактов — книга, которую можно создать; в ней собрано всё об артефактах. Рецепт смотрите в книге рецептов.", color: "light_purple"}}}, {text: " чтобы узнать, что он умеет!", color: "green"}]
tellraw @a[tag=!unlocker] [{text: "", color: "green"}, {selector: "@s"}, {text: " нашёл: ", color: "light_purple", bold: true}, {nbt: "currArtifact.name", storage: "ancient_artifacts:manual", interpret: true}, {text: "!"}]
tag @s remove unlocker
