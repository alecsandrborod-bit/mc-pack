execute unless entity @a[distance=..96] run return run function ancient_artifacts:shulker_castle/intro/reset
scoreboard players add @s animation 1
execute if score @s animation matches 5 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Hello...", color: "light_purple"}]
execute if score @s animation matches 13 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Hello?", color: "light_purple"}]
execute if score @s animation matches 20 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Прошу, помогите!", color: "light_purple"}]
execute if score @s animation matches 28 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Прямо здесь, посреди замка!", color: "light_purple"}]
execute if score @s animation matches 28 run effect give @s glowing infinite 0 true
execute if score @s animation matches 35 store result score .random temp run random value 1..5
execute if score @s animation matches 35 if score .random temp matches 1 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Ну же!", color: "light_purple"}]
execute if score @s animation matches 35 if score .random temp matches 2 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Сюда!", color: "light_purple"}]
execute if score @s animation matches 35 if score .random temp matches 3 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Please...", color: "light_purple"}]
execute if score @s animation matches 35 if score .random temp matches 4 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Я в отчаянии…", color: "light_purple"}]
execute if score @s animation matches 35 if score .random temp matches 5 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "У меня есть для вас добыча…", color: "light_purple"}]
execute if score @s animation matches 45 unless entity @a[distance=..5] run scoreboard players set @s animation 29
execute if score @s animation matches 28..45 if entity @a[distance=..5] run scoreboard players set @s animation 100
execute if score @s animation matches 105 run effect clear @s glowing
execute if score @s animation matches 105 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "О, вы пришли! Благодарю…", color: "light_purple"}]
execute if score @s animation matches 113 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Друзья-шалкеры выгнали меня из своего города…", color: "light_purple"}]
execute if score @s animation matches 122 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "и отравили меня!", color: "light_purple"}]
execute if score @s animation matches 127 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "И всё лишь потому, что я… не такой. Слишком… жёлтый…", color: "light_purple"}]
execute if score @s animation matches 139 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Мне нужна ваша помощь, чтобы снять яд…", color: "light_purple"}]
execute if score @s animation matches 151 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Для этого нужен один артефакт… любой редкости…", color: "light_purple"}]
execute if score @s animation matches 163 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Но чем реже артефакт, тем больше сил я полу… кхм, тем больше их у меня останется для мести!", color: "light_purple"}]
execute if score @s animation matches 175 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "И добыча ВАМ достанется получше — да, ВАС за это наградят!", color: "light_purple"}]
execute if score @s animation matches 187 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "\n 2 end artifact chests for a Common,\n 4 for an Uncommon,\n 6 for a Rare one,\n 8 for a Unique (expensive) one and\n 12 for a divine one!", color: "light_purple"}]
execute if score @s animation matches 202 store result score .random temp run random value 1..6
execute if score @s animation matches 202 if score .random temp matches 1 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Вы должны спасти мне жизнь!", color: "light_purple"}]
execute if score @s animation matches 202 if score .random temp matches 2 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Мне нужна сила!", color: "light_purple"}]
execute if score @s animation matches 202 if score .random temp matches 3 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Please...", color: "light_purple"}]
execute if score @s animation matches 202 if score .random temp matches 4 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Я в отчаянии…", color: "light_purple"}]
execute if score @s animation matches 202 if score .random temp matches 5 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "И за это вам ещё и добыча?", color: "light_purple"}]
execute if score @s animation matches 202 if score .random temp matches 6 run tellraw @a[distance=..64] [{text: "[Потерянный шалкер]: ", color: "yellow"}, {text: "Просто дайте мне артефакт… пожалуйста", color: "light_purple"}]
execute if score @s animation matches 217.. unless entity @s[tag=artifact_aquired] run scoreboard players set @s animation 201
execute if score @s animation matches 187 unless entity @s[tag=artifact_aquired] align xyz unless entity @e[type=interaction, dy=0] run summon minecraft:interaction ~0.5 ~ ~0.5 {width: 2.0f, height: 2.0f, Tags: ["shulker_king_offer"], response: true}
