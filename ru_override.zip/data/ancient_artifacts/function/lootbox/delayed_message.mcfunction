tellraw @a[tag=show_lootbox_message] [{text: "У вас ", color: "light_purple"}, {score: {name: "@s", objective: "lootbox_count"}}, {text: " сундуков ждут вас! Введите "}, {text: "/trigger lootbox", color: "blue", underlined: true, click_event: {action: "suggest_command", command: "/trigger lootbox"}}, {text: " , чтобы забрать!"}]
execute as @a[tag=show_lootbox_message] at @s run playsound block.note_block.bell
tag @a remove show_lootbox_message
