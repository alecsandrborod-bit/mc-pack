playsound block.note_block.didgeridoo master @s ~ ~ ~ 1 0.7
tellraw @s [{text: "[Ancient Artifacts]: ", color: "light_purple"}, {text: "Для этого нужен творческий режим!", color: "red"}]
scoreboard players reset @s aa.creative_book
