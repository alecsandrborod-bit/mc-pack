tellraw @s [{text: "[Ancient Artifacts]: ", color: "light_purple"}, {text: "Творческая книга выдана!", color: "green"}]
loot give @s loot ancient_artifacts:item/creative_book
scoreboard players reset @s aa.creative_book
