title @a[predicate=endfight:end_centre] times 0 100 100
title @a[predicate=endfight:end_centre] subtitle {"text":"Пленитель Края"}
title @a[predicate=endfight:end_centre] title {"text":"Дракон Края","color":"dark_purple"}