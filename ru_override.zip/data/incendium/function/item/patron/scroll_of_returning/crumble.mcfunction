# from: ./fail OR ./activate
# @s: player who used scroll

# $rand is set beforehand in activate or fail functions, since the probabilities are reversed
execute if score $rand in.dummy matches 1.. run tellraw @s {translate:"incendium.item.returning_scroll.system.withstood",fallback:"На этот раз древний приём выдержал…", "italic": true, "color": "#D393F5"}

execute if score $rand in.dummy matches 1.. run loot replace entity @s[tag=in.mainhand_scroll] weapon.mainhand loot incendium:artifact/patron/scroll_of_returning
execute if score $rand in.dummy matches 1.. run loot replace entity @s[tag=in.offhand_scroll] weapon.offhand loot incendium:artifact/patron/scroll_of_returning

execute unless score $rand in.dummy matches 1.. run tellraw @s {translate:"incendium.item.returning_scroll.system.crumble",fallback:"Древний приём рассыпался от применения", "italic": true, "color": "#D393F5"}