# from ./using
# @s: holding raganrok too long

scoreboard players operation $random in.dummy = @s in.ragnarok
scoreboard players operation $random in.dummy -= #250 in.constants
execute if predicate incendium:weather/thunder run scoreboard players operation $random in.dummy *= #2 in.constants

scoreboard players operation $random in.dummy < #75 in.constants

execute if predicate incendium:random/other/x if predicate incendium:random/other/x if predicate incendium:random/10 run summon lightning_bolt

title @s[predicate=!incendium:weather/thunder] actionbar [{translate:"incendium.item.ragnarok.name",fallback:"Рагнарёк", "color": "#CCEBDB", "bold": true}, " ", {translate:"incendium.item.ragnarok.system.unstable",fallback:"делается всё нестабильнее, пока держишь его силу в себе", "color":"#ABC4B8", "bold": false}]

title @s[predicate=incendium:weather/thunder] actionbar [{translate:"incendium.item.ragnarok.name",fallback:"Рагнарёк", "color": "#CCEBDB", "bold": true}, " ", {translate:"incendium.item.ragnarok.system.storm",fallback:"во время грозы делается ещё нестабильнее", "color":"#ABC4B8", "bold": false}]
