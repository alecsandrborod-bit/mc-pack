# from: ./using

scoreboard players set @s in.wet 300
scoreboard players set @s in.trailblazer 0

tellraw @s [{translate:"incendium.item.trailblazer.name",fallback:"Первопроходец", "color": "#F7823E", "bold": true}, " ", {translate:"incendium.item.trailblazer.system.wet",fallback:"намок. Просушите его, прежде чем пользоваться снова"}]

function incendium:item/trailblazer/fix

playsound minecraft:entity.generic.extinguish_fire master @a ~ ~ ~ 2 0.1
