# from ../2s
# @s: player, at hovering_inferno

tellraw @s [{translate:"incendium.inferno.system.warning1",fallback:"Нельзя покинуть", "color": "#ff6600"}, " ", {translate:"incendium.admin.menu.inferno",fallback:"Парящее Инферно", "bold": true}, " ", {translate:"incendium.inferno.system.warning2",fallback:"бой на последней ступени"}]

title @s title ""
title @s subtitle {translate:"incendium.inferno.system.warning",fallback:"Вернитесь в бой", "color": "#ff6600"}

effect give @s instant_damage 1 0 true
