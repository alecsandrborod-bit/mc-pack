# from: entity/other/init

tellraw @a[distance=..16] [{translate:"incendium",fallback:"Incendium", "color": "#ff6600", "bold": true}, ": ", {translate:"incendium.admin.menu.inferno",fallback:"Парящее Инферно", "bold": true}, " ", {translate:"incendium.inferno.system.running",fallback:"уже запущен в другом месте"}]
