# from: ../end/bad

tellraw @a[tag=in.was_inferno_fight] [{translate:"incendium",fallback:"Incendium", "color": "#ff6600", "bold": true}, ": ", {translate:"incendium.admin.menu.inferno",fallback:"Парящее Инферно", "bold": true}, " ", {translate:"incendium.inferno.system.fail.final",fallback:"одолел всех соперников и теперь мирно покоится"}]

tag @a remove in.was_inferno_fight
