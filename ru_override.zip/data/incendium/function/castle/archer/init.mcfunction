# from: ../mob/init
# @s: archer

data modify entity @s CustomName set value {translate:"incendium.mob.castle.archer.name",fallback:"Пиглин-лучник"}

tag @s add in.activate_far
