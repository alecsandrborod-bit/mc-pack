team add fabled_roots.frostborne {"bold":false,"color":"#A9D6E5","italic":false,"text":"Морозорождённый"}
team add fabled_roots.moonshroud {"bold":false,"color":"#B0B7D6","italic":false,"text":"Лунная тень"}
team add fabled_roots.netherian {"bold":false,"color":"#B23333","italic":false,"text":"Незерец"}
team add fabled_roots.oakhearted {"bold":false,"color":"#5B7B4D","italic":false,"text":"Дубосердый"}
team add fabled_roots.orebringer {"bold":false,"color":"#857A6F","italic":false,"text":"Рудонос"}
team add fabled_roots.turtlekin {"bold":false,"color":"#3C92A4","italic":false,"text":"Панцирник"}
team add fabled_roots.dunesworn {"bold":false,"color":"#C2A76D","italic":false,"text":"Пустынник"}
team add fabled_roots.endling {"bold":false,"color":"#5D3A9B","italic":false,"text":"Эндлинг"}
team add fabled_roots.palehearted {"bold":false,"color":"#E8DADA","italic":false,"text":"Бледносердый"}
team add fabled_roots.aetherian {"bold":false,"color":"#a8fcff","italic":false,"text":"Эфириец"}

team modify fabled_roots.frostborne color white
team modify fabled_roots.moonshroud color white
team modify fabled_roots.netherian color white
team modify fabled_roots.oakhearted color white
team modify fabled_roots.orebringer color white
team modify fabled_roots.turtlekin color white
team modify fabled_roots.dunesworn color white
team modify fabled_roots.endling color white
team modify fabled_roots.palehearted color white
team modify fabled_roots.aetherian color white