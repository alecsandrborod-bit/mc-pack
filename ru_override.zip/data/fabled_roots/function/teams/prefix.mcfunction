execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.frostborne prefix [{"text":"Морозорождённый","color":"#A9D6E5"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.frostborne prefix ""

execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.moonshroud prefix [{"text":"Лунная тень","color":"#B0B7D6"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.moonshroud prefix ""

execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.netherian prefix [{"text":"Незерец","color":"#B23333"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.netherian prefix ""

execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.oakhearted prefix [{"text":"Дубосердый","color":"#5B7B4D"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.oakhearted prefix ""

execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.orebringer prefix [{"text":"Рудонос","color":"#857A6F"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.orebringer prefix ""

execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.turtlekin prefix [{"text":"Панцирник","color":"#3C92A4"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.turtlekin prefix ""

execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.dunesworn prefix [{"text":"Пустынник","color":"#C2A76D"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.dunesworn prefix ""

execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.endling prefix [{"text":"Эндлинг","color":"#5D3A9B"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.endling prefix ""

execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.palehearted prefix [{"text":"Бледносердый","color":"#E8DADA"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.palehearted prefix ""

execute if data storage eden:settings fabled_roots{prefix:"enabled"} run team modify fabled_roots.aetherian prefix [{"text":"Эфириец","color":"#D4F1FF"},{"text":" | ","color":"dark_gray"}]
execute if data storage eden:settings fabled_roots{prefix:"disabled"} run team modify fabled_roots.aetherian prefix ""