loot give @s loot svoi:discs/bazovyy_minimum
loot give @s loot svoi:discs/bohemian_rhapsody
loot give @s loot svoi:discs/hochu_peremen
loot give @s loot svoi:discs/rozovoe_vino
loot give @s loot svoi:discs/starboy
loot give @s loot svoi:discs/teen_spirit
loot give @s loot svoi:discs/wide_awake
